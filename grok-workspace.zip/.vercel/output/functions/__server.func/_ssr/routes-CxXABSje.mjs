import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Code, r as Image, t as Video } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CxXABSje.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FONTS = [
	{
		id: "outfit",
		label: "Ince",
		family: "var(--font-outfit)"
	},
	{
		id: "nunito",
		label: "Yumaloq",
		family: "var(--font-nunito)"
	},
	{
		id: "fraunces",
		label: "Serif",
		family: "var(--font-fraunces)"
	},
	{
		id: "cormorant",
		label: "Klassik",
		family: "var(--font-cormorant)"
	},
	{
		id: "oswald",
		label: "Tor",
		family: "var(--font-oswald)"
	},
	{
		id: "plex",
		label: "Mono",
		family: "var(--font-plex)"
	}
];
var WALLPAPERS = [
	{
		id: "tuynuk",
		name: "Qora tuynuk",
		group: "live",
		depth: false
	},
	{
		id: "matritsa",
		name: "Matritsa",
		group: "live",
		depth: false
	},
	{
		id: "aurora",
		name: "Aurora",
		group: "live",
		depth: false
	},
	{
		id: "yulduz",
		name: "Yulduzlar",
		group: "live",
		depth: false
	},
	{
		id: "chog",
		name: "Cho‘g‘",
		group: "live",
		depth: false
	},
	{
		id: "nihol",
		name: "Nihol",
		group: "studio",
		depth: true
	},
	{
		id: "orxideya",
		name: "Orxideya",
		group: "studio",
		depth: true
	},
	{
		id: "qum",
		name: "Qumlar",
		group: "studio",
		depth: true
	},
	{
		id: "ravoq",
		name: "Ravoq",
		group: "studio",
		depth: true
	},
	{
		id: "dengiz",
		name: "Dengiz",
		group: "studio",
		depth: true
	},
	{
		id: "yomgir",
		name: "Yomg‘ir",
		group: "studio",
		depth: true
	},
	{
		id: "ipak",
		name: "Ipak",
		group: "studio",
		depth: true
	}
];
function wallpaperMeta(id) {
	return WALLPAPERS.find((item) => item.id === id);
}
function isScene(id) {
	return id !== "tuynuk" && id !== "user-image" && id !== "user-video" && id !== "user-html";
}
function hasSceneFront(id) {
	return wallpaperMeta(id)?.depth === true;
}
function clockCssColor(color) {
	if (color === "ink") return "var(--color-ink)";
	if (color === "silver") return "var(--color-silver)";
	if (color === "amber") return "var(--color-amber)";
	return color;
}
function colorToHex(color) {
	if (color === "silver") return "#d8d2c8";
	if (color === "amber") return "#e39a52";
	if (color.startsWith("#") && color.length >= 7) return color.slice(0, 7);
	return "#f4ece3";
}
var DAYS = [
	"Yakshanba",
	"Dushanba",
	"Seshanba",
	"Chorshanba",
	"Payshanba",
	"Juma",
	"Shanba"
];
var MONTHS = [
	"yanvar",
	"fevral",
	"mart",
	"aprel",
	"may",
	"iyun",
	"iyul",
	"avgust",
	"sentabr",
	"oktabr",
	"noyabr",
	"dekabr"
];
var DB_NAME = "qatlam";
var STORE = "files";
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
}
async function idbSet(key, value) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(value, key);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
	db.close();
}
async function idbGet(key) {
	const db = await openDb();
	const value = await new Promise((resolve, reject) => {
		const req = db.transaction(STORE, "readonly").objectStore(STORE).get(key);
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
	db.close();
	return value;
}
async function idbDel(key) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).delete(key);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
	db.close();
}
async function imageHasTransparency(file) {
	const bitmap = await createImageBitmap(file);
	const canvas = document.createElement("canvas");
	canvas.width = Math.min(64, bitmap.width);
	canvas.height = Math.min(64, bitmap.height);
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) {
		bitmap.close();
		return false;
	}
	ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
	bitmap.close();
	const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
	for (let i = 3; i < data.length; i += 16) if (data[i] < 248) return true;
	return false;
}
var qora_tuynuk_default = "<!doctype html>\n<html lang=\"uz\">\n<head>\n<meta charset=\"utf-8\">\n<title>Qora tuynuk — bosh ekran</title>\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">\n<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n<link href=\"https://fonts.googleapis.com/css2?family=Outfit:wght@200;300;500&display=swap\" rel=\"stylesheet\">\n<style>\n:root{--ink:#fff3e4;--mute:rgba(255,232,206,.62);--line:rgba(255,196,138,.24);--glow:#ffb15c;--void:#020203;color-scheme:dark}\n*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}\nhtml,body{margin:0;height:100%;overflow:hidden;background:var(--void);color:var(--ink);font-family:Outfit,system-ui,-apple-system,\"Segoe UI\",sans-serif;touch-action:none;user-select:none;-webkit-user-select:none}\ncanvas{position:fixed;inset:0;width:100%;height:100%;display:block}\n#fx{z-index:1}\n.nogl #gl{display:none}\n.nogl body{background:radial-gradient(circle at 50% 47%,#000 0 13%,#ffd9a0 14%,#b4561a 19%,#4a1d08 28%,var(--void) 52%)}\n\n#hint{position:fixed;z-index:3;left:0;right:0;bottom:0;padding:0 24px calc(env(safe-area-inset-bottom,0px) + 34px);text-align:center;pointer-events:none;transition:opacity .7s}\n#hint b{display:block;font-weight:300;font-size:19px;letter-spacing:.01em;text-shadow:0 2px 18px #000}\n#hint span{display:block;margin-top:8px;font-size:14px;font-weight:300;color:var(--mute);text-shadow:0 2px 14px #000}\n.open #hint{opacity:0}\n\n#home{position:fixed;z-index:2;inset:0;display:flex;flex-direction:column;justify-content:space-between;align-items:center;padding:calc(env(safe-area-inset-top,0px) + 56px) 22px calc(env(safe-area-inset-bottom,0px) + 22px);pointer-events:none}\n.open #home>*{pointer-events:auto}\n.r{opacity:0;transform:translateY(16px) scale(.94);filter:blur(10px);transition:opacity 1s cubic-bezier(.2,.8,.2,1),transform 1s cubic-bezier(.2,.8,.2,1),filter 1s;transition-delay:calc(var(--i,0)*70ms + 350ms)}\n.open .r{opacity:1;transform:none;filter:none}\n.clock{text-align:center;text-shadow:0 4px 40px rgba(0,0,0,.7)}\n.clock b{display:block;font-weight:200;font-size:clamp(76px,22vw,128px);line-height:1;letter-spacing:-.02em;font-variant-numeric:tabular-nums}\n.clock span{display:block;margin-top:6px;font-size:17px;font-weight:300;color:var(--mute)}\n.bottom{width:100%;max-width:430px;display:flex;flex-direction:column;gap:20px}\n.search{width:100%;height:48px;border-radius:24px;border:1px solid var(--line);background:rgba(20,10,4,.55);color:var(--ink);font:300 16px Outfit,system-ui,sans-serif;padding:0 20px;outline:0}\n.search::placeholder{color:var(--mute)}\n.search:focus-visible,.app:focus-visible,#relock:focus-visible{outline:2px solid var(--glow);outline-offset:3px}\n.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:18px 8px}\n.app{display:flex;flex-direction:column;align-items:center;gap:7px;color:var(--ink);text-decoration:none;font-size:12.5px;font-weight:300;text-shadow:0 1px 10px #000;border-radius:16px}\n.app i{display:grid;place-items:center;width:60px;height:60px;border-radius:19px;font-style:normal;font-size:26px;background:linear-gradient(155deg,rgba(255,196,138,.24),rgba(255,120,40,.06) 70%);border:1px solid var(--line);box-shadow:inset 0 1px 0 rgba(255,236,212,.3),0 10px 26px rgba(0,0,0,.5);transition:transform .25s}\n.app:active i{transform:scale(.9)}\n.dock{display:flex;justify-content:space-around;padding:12px 8px;border-radius:30px;border:1px solid var(--line);background:rgba(18,9,4,.6)}\n.dock .app span{display:none}\n#relock{align-self:center;border:0;background:none;color:var(--mute);font:300 14px Outfit,system-ui,sans-serif;padding:6px 14px;border-radius:14px;cursor:pointer}\n#relock:hover{color:var(--ink)}\n</style>\n</head>\n<body>\n<canvas id=\"gl\"></canvas>\n<canvas id=\"fx\"></canvas>\n\n<div id=\"hint\" aria-live=\"polite\">\n  <b>Meteorni qora tuynukka yoʻnaltiring</b>\n  <span>Ekranni bosib turing — meteor barmogʻingiz tomon uchadi</span>\n</div>\n\n<main id=\"home\" aria-label=\"Bosh ekran\">\n  <div class=\"clock r\"><b id=\"clk\">09:41</b><span id=\"dt\"></span></div>\n  <div class=\"bottom\">\n    <input class=\"search r\" style=\"--i:1\" type=\"search\" placeholder=\"Koinotdan qidiring…\" aria-label=\"Qidiruv\">\n    <div class=\"grid\" id=\"grid\"></div>\n    <nav class=\"dock r\" style=\"--i:5\" id=\"dock\" aria-label=\"Doimiy ilovalar\"></nav>\n    <button id=\"relock\" class=\"r\" style=\"--i:6\" type=\"button\">Qayta qulflash</button>\n  </div>\n</main>\n\n<script>\n\"use strict\";\nconst $=s=>document.querySelector(s);\nconst root=document.documentElement;\n\n/* ---------- Ilovalar va soat ---------- */\nconst apps=[[\"🖼\",\"Galereya\"],[\"🎵\",\"Musiqa\"],[\"🗺\",\"Xarita\"],[\"⛅\",\"Ob-havo\"],[\"📅\",\"Taqvim\"],[\"📝\",\"Eslatma\"],[\"📁\",\"Fayllar\"],[\"⚙️\",\"Sozlamalar\"]];\nconst dock=[[\"📞\",\"Telefon\"],[\"💬\",\"Xabarlar\"],[\"🌐\",\"Brauzer\"],[\"📷\",\"Kamera\"]];\nconst tile=(a,i)=>`<a class=\"app r\" style=\"--i:${i+2}\" href=\"#\" aria-label=\"${a[1]}\"><i>${a[0]}</i><span>${a[1]}</span></a>`;\n$(\"#grid\").innerHTML=apps.map(tile).join(\"\");\n$(\"#dock\").innerHTML=dock.map((a,i)=>tile(a,i).replace('app r','app')).join(\"\");\ndocument.addEventListener(\"click\",e=>{if(e.target.closest(\".app\"))e.preventDefault()});\nconst days=[\"Yakshanba\",\"Dushanba\",\"Seshanba\",\"Chorshanba\",\"Payshanba\",\"Juma\",\"Shanba\"];\nconst months=[\"yanvar\",\"fevral\",\"mart\",\"aprel\",\"may\",\"iyun\",\"iyul\",\"avgust\",\"sentabr\",\"oktabr\",\"noyabr\",\"dekabr\"];\nfunction tick(){const d=new Date();$(\"#clk\").textContent=String(d.getHours()).padStart(2,\"0\")+\":\"+String(d.getMinutes()).padStart(2,\"0\");$(\"#dt\").textContent=days[d.getDay()]+\", \"+d.getDate()+\"-\"+months[d.getMonth()]}\ntick();setInterval(tick,10000);\n\n/* ---------- WebGL: Shvartsshild nurlari bilan qora tuynuk ---------- */\nconst VS=\"attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}\";\nconst FS=`\n#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nuniform vec2 uRes;uniform float uT,uFlash,uDim;\nfloat h2(vec2 p){p=fract(p*vec2(.1031,.1030));p+=dot(p,p.yx+33.33);return fract((p.x+p.y)*p.x);}\nfloat h3(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}\nfloat n3(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);\n return mix(mix(mix(h3(i),h3(i+vec3(1,0,0)),f.x),mix(h3(i+vec3(0,1,0)),h3(i+vec3(1,1,0)),f.x),f.y),\n            mix(mix(h3(i+vec3(0,0,1)),h3(i+vec3(1,0,1)),f.x),mix(h3(i+vec3(0,1,1)),h3(i+vec3(1,1,1)),f.x),f.y),f.z);}\nfloat fb(vec3 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*n3(p);p*=2.02;a*=.5;}return s;}\nvec3 stl(vec3 d,float sc,float th,float sz){\n vec3 q=d*sc,id=floor(q),f=fract(q)-.5;float h=h3(id);\n if(h<th)return vec3(0.);\n vec3 o=(vec3(h3(id+7.1),h3(id+13.7),h3(id+29.3))-.5)*.5;\n float dd=dot(f-o,f-o);\n float b=exp(-dd/(sz*sz))*(.25+1.1*pow(fract(h*57.3),3.));\n return mix(vec3(1.,.72,.5),vec3(.65,.78,1.),fract(h*91.7))*b;}\nvec3 sky(vec3 d){\n float hz=n3(d*2.6+3.1)*n3(d*5.3+9.)+.5*n3(d*11.);\n vec3 c=vec3(.0030,.0034,.0048)+hz*hz*vec3(.030,.022,.016);\n c+=stl(d,110.,.985,.11)*2.4+stl(d,330.,.975,.15)*1.2+stl(d,760.,.97,.22)*.8;\n return c;}\nvoid main(){\n float sc=min(uRes.x,uRes.y*.55);\n vec2 uv=(gl_FragCoord.xy-uRes*vec2(.5,.53))/sc;\n float cr=cos(.3),sr=sin(.3);\n vec2 w=vec2(cr*uv.x+sr*uv.y,-sr*uv.x+cr*uv.y);\n float e=.15;\n vec3 ro=vec3(0.,28.*sin(e),28.*cos(e));\n vec3 f=-normalize(ro),rt=normalize(cross(f,vec3(0.,1.,0.))),up=cross(rt,f);\n vec3 v=normalize(f+.42*(w.x*rt+w.y*up));\n vec3 p=ro;\n float hh=length(cross(p,v)),H2=hh*hh;\n vec3 col=vec3(0.);float tr=1.;bool hit=false,esc=false;\n for(int i=0;i<130;i++){\n  float r2=dot(p,p),r=sqrt(r2);\n  if(r<1.){hit=true;break;}\n  if(r>45.&&dot(p,v)>0.){esc=true;break;}\n  float dt=.06+.12*max(r-2.2,0.);\n  v=normalize(v-1.5*H2*p/(r2*r2*r)*dt);\n  vec3 pn=p+v*dt;\n  if(p.y*pn.y<0.){\n   vec3 q=mix(p,pn,p.y/(p.y-pn.y));\n   float rr=length(q.xz);\n   if(rr>3.&&rr<12.){\n    float ph=atan(q.z,q.x)+2.2/(rr*sqrt(rr))*uT*1.4;\n    float n1=fb(vec3(cos(ph)*3.,sin(ph)*3.,rr*16.));\n    float n2=fb(vec3(cos(ph+1.7)*7.,sin(ph+1.7)*7.,rr*40.+5.));\n    float dens=clamp((.55*n1+.45*n2-.22)*2.6,0.,1.);\n    float edge=smoothstep(3.,3.6,rr)*(1.-smoothstep(8.,12.,rr));\n    vec3 tg=normalize(vec3(-q.z,0.,q.x));\n    float beta=sqrt(.5/(rr-1.));\n    float dop=sqrt(1.-beta*beta)/(1.-beta*dot(tg,-v));\n    float ff=clamp(dop*sqrt(1.-1./rr),.25,2.2);\n    float T=pow(3./rr,.75)*ff;\n    vec3 cc=T*vec3(1.,.38+.45*T,.1+.6*T*T);\n    float I=pow(3./rr,2.2)*ff*ff*ff*(.35+1.6*dens)*1.5;\n    float al=edge*clamp(.2+dens*.9,0.,.95);\n    col+=tr*cc*I*al;tr*=1.-al;\n   }\n  }\n  p=pn;\n }\n if(!hit&&(esc||dot(p,p)>36.))col+=tr*sky(v);\n float ring=exp(-pow((hh-2.6)/.04,2.))*(.45+.55*clamp(dot(normalize(w+1e-5),vec2(-.6,-.8))*.5+.5,0.,1.));\n col+=ring*vec3(1.,.78,.5)*.9+vec3(1.,.55,.2)*.04*exp(-pow((hh-2.6)/.5,2.));\n col*=mix(1.,.72,uDim);\n col=col*(1.+uFlash*1.2)+uFlash*vec3(1.,.6,.3)*.5*exp(-dot(uv,uv)*5.);\n col*=1.-.35*smoothstep(.5,1.4,length(uv));\n col*=1.1;\n col=(col*(2.51*col+.03))/(col*(2.43*col+.59)+.14);\n col=pow(clamp(col,0.,1.),vec3(1./2.2));\n col+=(h2(gl_FragCoord.xy+uT)-.5)/255.;\n gl_FragColor=vec4(col,1.);\n}`;\nconst glc=$(\"#gl\");\nconst gl=glc.getContext(\"webgl\",{antialias:false,alpha:false,powerPreference:\"high-performance\"})||glc.getContext(\"experimental-webgl\");\nlet U={};\nif(gl){\n  const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(o));return o};\n  try{\n    const pr=gl.createProgram();\n    gl.attachShader(pr,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,FS));\n    gl.linkProgram(pr);gl.useProgram(pr);\n    gl.bindBuffer(gl.ARRAY_BUFFER,gl.createBuffer());\n    gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);\n    const loc=gl.getAttribLocation(pr,\"a\");gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);\n    [\"uRes\",\"uT\",\"uFlash\",\"uDim\"].forEach(n=>U[n]=gl.getUniformLocation(pr,n));\n  }catch(err){console.error(err);root.classList.add(\"nogl\")}\n}else root.classList.add(\"nogl\");\nconst ok=!root.classList.contains(\"nogl\");\n\n/* ---------- Oʻlcham va sifat (ekranning haqiqiy piksel zichligida) ---------- */\nconst fx=$(\"#fx\"),fc=fx.getContext(\"2d\");\nlet W,H,s,cx,cy,R,Q=1,fk=1;\nfunction resize(){\n  W=innerWidth;H=innerHeight;\n  const dpr=Math.min(devicePixelRatio||1,3);\n  let k=dpr*Q;k=Math.min(k,Math.sqrt(1.4e7/(W*H)));\n  glc.width=Math.floor(W*k);glc.height=Math.floor(H*k);\n  fk=Math.min(dpr,2);fx.width=Math.floor(W*fk);fx.height=Math.floor(H*fk);\n  s=Math.min(W,H*.55);cx=W*.5;cy=H*.47;R=.22*s;\n  if(ok)gl.viewport(0,0,glc.width,glc.height);\n}\naddEventListener(\"resize\",resize);resize();\n\n/* ---------- Meteor ---------- */\nlet state=\"fly\",M,trail=[],sparks=[],ptr=null,aim=false,flash=0,dim=0,shock=-1,fall=null;\nfunction spawn(){\n  const sd=Math.random()*4|0,m=50,r=Math.random;\n  const x=sd==0?-m:sd==1?W+m:r()*W, y=sd==2?-m:sd==3?H+m:r()*H;\n  const a=Math.atan2(H*(.2+.6*r())-y,W*(.2+.6*r())-x),sp=s*(.55+.3*r());\n  M={x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,ph:r()*6.28};trail=[];\n}\nspawn();\naddEventListener(\"pointerdown\",e=>{if(state==\"fly\"){ptr={x:e.clientX,y:e.clientY};aim=false}});\naddEventListener(\"pointermove\",e=>{if(ptr)ptr={x:e.clientX,y:e.clientY}});\n[\"pointerup\",\"pointercancel\"].forEach(n=>addEventListener(n,()=>ptr=null));\naddEventListener(\"keydown\",e=>{if((e.key==\"Enter\"||e.key==\" \")&&state==\"fly\"&&!e.target.closest(\"input,button\")){aim=true;e.preventDefault()}});\n$(\"#relock\").addEventListener(\"click\",()=>{document.body.classList.remove(\"open\");state=\"fly\";aim=false;spawn()});\n\nfunction step(dt,now){\n  if(state==\"fly\"){\n    const A=1.1*s;\n    let dx=cx-M.x,dy=cy-M.y,d=Math.hypot(dx,dy)||1;\n    const g=A*Math.pow(R/Math.max(d,R*.6),2);\n    M.vx+=dx/d*g*dt;M.vy+=dy/d*g*dt;\n    const tgt=aim?{x:cx,y:cy}:ptr;\n    if(tgt){\n      const ex=tgt.x-M.x,ey=tgt.y-M.y,dd=Math.hypot(ex,ey)||1,des=Math.min(s*1.15,dd*4),k=Math.min(1,5*dt);\n      M.vx+=(ex/dd*des-M.vx)*k;M.vy+=(ey/dd*des-M.vy)*k;\n    }else{ // erkin uchish: ozgina egri-bugri\n      const sp=Math.hypot(M.vx,M.vy),a=Math.atan2(M.vy,M.vx)+Math.sin(now*.9+M.ph)*.35*dt;\n      M.vx=Math.cos(a)*sp;M.vy=Math.sin(a)*sp;\n    }\n    const sp=Math.hypot(M.vx,M.vy),mx=s*1.7;if(sp>mx){M.vx*=mx/sp;M.vy*=mx/sp}\n    M.x+=M.vx*dt;M.y+=M.vy*dt;\n    d=Math.hypot(M.x-cx,M.y-cy);\n    if(d<R){\n      const sg=Math.sign((M.x-cx)*M.vy-(M.y-cy)*M.vx)||1;\n      fall={t:0,d0:d,a0:Math.atan2(M.y-cy,M.x-cx),sg};state=\"fall\";ptr=null;\n    }else if(M.x<-120||M.x>W+120||M.y<-120||M.y>H+120)spawn();\n  }else if(state==\"fall\"){\n    fall.t+=dt;const u=Math.min(1,fall.t/1.0);\n    const r=fall.d0*Math.pow(1-u,1.8),a=fall.a0+fall.sg*(u*2.4+u*u*3.6);\n    M.x=cx+Math.cos(a)*r;M.y=cy+Math.sin(a)*r;\n    flash=Math.max(flash,u*u*.25);\n    if(u>=1){state=\"open\";flash=1;shock=0;document.body.classList.add(\"open\");trail=[]}\n  }\n  flash*=Math.exp(-2.4*dt);if(shock>=0)shock+=dt;\n  dim+=((state==\"open\"?1:0)-dim)*Math.min(1,1.6*dt);\n  if(state!=\"open\"){\n    trail.push({x:M.x,y:M.y,t:now});\n    while(trail.length&&now-trail[0].t>(state==\"fall\"?1.1:.7))trail.shift();\n    if(Math.random()<.9)sparks.push({x:M.x,y:M.y,vx:(Math.random()-.5)*60,vy:(Math.random()-.5)*60,l:.5+Math.random()*.4,m:.9});\n  }\n  sparks=sparks.filter(p=>(p.l-=dt)>0);\n  for(const p of sparks){p.x+=p.vx*dt;p.y+=p.vy*dt}\n}\nfunction draw(now){\n  fc.setTransform(fk,0,0,fk,0,0);fc.clearRect(0,0,W,H);\n  fc.globalCompositeOperation=\"lighter\";fc.lineCap=\"round\";\n  for(const p of sparks){fc.fillStyle=`rgba(255,${150+p.l*120|0},70,${Math.min(1,p.l*1.6)*.8})`;fc.fillRect(p.x,p.y,1.8,1.8)}\n  if(state!=\"open\"){\n    const d=Math.hypot(M.x-cx,M.y-cy);\n    const near=Math.max(0,Math.min(1,(R*3-d)/(R*2)));\n    let hr=s*.011*(1+.7*(1-near)*0)*(state==\"fall\"?Math.max(.15,1-fall.t):1);\n    hr*=.75+.25*(1-near);\n    for(let i=1;i<trail.length;i++){\n      const a=trail[i-1],b=trail[i],age=(now-b.t)/(state==\"fall\"?1.1:.7),k=Math.max(0,1-age);\n      fc.strokeStyle=`rgba(255,${120+k*110|0},${50+k*70|0},${Math.pow(k,1.4)*.85})`;\n      fc.lineWidth=Math.max(.6,hr*2.4*k);\n      fc.beginPath();fc.moveTo(a.x,a.y);fc.lineTo(b.x,b.y);fc.stroke();\n    }\n    const g=fc.createRadialGradient(M.x,M.y,0,M.x,M.y,hr*5);\n    g.addColorStop(0,\"rgba(255,248,235,1)\");g.addColorStop(.25,\"rgba(255,190,110,.75)\");g.addColorStop(1,\"rgba(255,110,30,0)\");\n    fc.fillStyle=g;fc.beginPath();fc.arc(M.x,M.y,hr*5,0,6.2832);fc.fill();\n  }\n  if(shock>=0&&shock<1.4){\n    const u=shock/1.4;\n    fc.strokeStyle=`rgba(255,200,140,${(1-u)*.7})`;fc.lineWidth=Math.max(.5,4*(1-u));\n    fc.beginPath();fc.arc(cx,cy,R*(1+u*5),0,6.2832);fc.stroke();\n  }\n}\n\n/* ---------- Asosiy sikl ---------- */\nlet last=performance.now(),acc=0,fn=0;\nfunction frame(t){\n  const raw=(t-last)/1000;last=t;\n  acc+=raw;\n  if(++fn==40){if(acc/40>.026&&Q>.5){Q=Math.max(.5,Q-.12);resize()}acc=0;fn=0}\n  const now=t/1000;\n  step(Math.min(.05,raw),now);draw(now);\n  if(ok){gl.uniform2f(U.uRes,glc.width,glc.height);gl.uniform1f(U.uT,now);gl.uniform1f(U.uFlash,Math.min(1,flash));gl.uniform1f(U.uDim,dim*.55);gl.drawArrays(gl.TRIANGLES,0,3)}\n  requestAnimationFrame(frame);\n}\nrequestAnimationFrame(frame);\n<\/script>\n</body>\n</html>\n";
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function memoryStorage() {
	return {
		getItem: () => null,
		setItem: () => {},
		removeItem: () => {}
	};
}
var useQatlam = create()(persist((set, get) => ({
	wallpaper: "qum",
	font: "outfit",
	weight: 200,
	scale: 1.08,
	color: "ink",
	shadow: true,
	seconds: false,
	showDate: true,
	showClock: true,
	clockY: 12,
	depth: true,
	maskX: 50,
	maskY: 62,
	maskW: 78,
	maskH: 52,
	feather: 16,
	userImageHasAlpha: false,
	editing: false,
	imageUrl: null,
	videoUrl: null,
	html: "",
	mediaReady: false,
	notice: null,
	selectWallpaper: (id) => {
		const meta = wallpaperMeta(id);
		set({
			wallpaper: id,
			depth: meta ? meta.depth : get().depth,
			showClock: true,
			notice: null
		});
	},
	setFont: (font) => set({ font }),
	setWeight: (weight) => set({ weight }),
	setScale: (scale) => set({ scale: clamp(scale, .7, 1.5) }),
	setColor: (color) => set({ color }),
	setShadow: (shadow) => set({ shadow }),
	setSeconds: (seconds) => set({ seconds }),
	setShowDate: (showDate) => set({ showDate }),
	setShowClock: (showClock) => set({ showClock }),
	setClockY: (clockY) => set({ clockY: clamp(clockY, 6, 34) }),
	setDepth: (depth) => set({ depth }),
	setMask: (patch) => set(patch),
	setEditing: (editing) => set({ editing }),
	clearNotice: () => set({ notice: null }),
	useSampleHtml: async () => {
		await idbSet("html", qora_tuynuk_default);
		set({
			html: qora_tuynuk_default,
			wallpaper: "user-html",
			showClock: false,
			depth: false,
			notice: null
		});
	},
	useImageFile: async (file) => {
		if (!file.type.startsWith("image/")) {
			set({ notice: "Rasm faylini tanlang." });
			return;
		}
		if (file.size > 12582912) {
			set({ notice: "Rasm 12 MB dan kichik bo‘lsin." });
			return;
		}
		let alpha = false;
		try {
			alpha = await imageHasTransparency(file);
		} catch {
			set({ notice: "Bu rasm ochilmadi. Boshqa formatni sinab ko‘ring." });
			return;
		}
		try {
			await idbSet("image", file);
		} catch {
			set({ notice: "Rasm sig‘madi. Kichikroq fayl tanlang." });
			return;
		}
		const prev = get().imageUrl;
		if (prev) URL.revokeObjectURL(prev);
		set({
			imageUrl: URL.createObjectURL(file),
			userImageHasAlpha: alpha,
			wallpaper: "user-image",
			depth: true,
			showClock: true,
			notice: alpha ? "Shaffof rasm aniqlandi — soat uning orqasida." : null
		});
	},
	useVideoFile: async (file) => {
		if (!file.type.startsWith("video/")) {
			set({ notice: "Video faylini tanlang." });
			return;
		}
		if (file.size > 41943040) {
			set({ notice: "Video 40 MB dan kichik bo‘lsin." });
			return;
		}
		try {
			await idbSet("video", file);
		} catch {
			set({ notice: "Video sig‘madi. Kichikroq fayl tanlang." });
			return;
		}
		const prev = get().videoUrl;
		if (prev) URL.revokeObjectURL(prev);
		set({
			videoUrl: URL.createObjectURL(file),
			wallpaper: "user-video",
			depth: true,
			showClock: true,
			notice: null
		});
	},
	useHtmlFile: async (file) => {
		if (file.size > 4e5) {
			set({ notice: "HTML 400 KB dan kichik bo‘lsin." });
			return;
		}
		const text = await file.text();
		await get().useHtmlText(text);
	},
	useHtmlText: async (text) => {
		const trimmed = text.trim();
		if (!trimmed) {
			set({ notice: "HTML kod bo‘sh." });
			return;
		}
		if (trimmed.length > 4e5) {
			set({ notice: "HTML 400 KB dan kichik bo‘lsin." });
			return;
		}
		try {
			await idbSet("html", trimmed);
		} catch {
			set({ notice: "HTML saqlanmadi." });
			return;
		}
		set({
			html: trimmed,
			wallpaper: "user-html",
			showClock: false,
			depth: false,
			notice: null
		});
	},
	clearUserMedia: async (kind) => {
		await idbDel(kind === "image" ? "image" : kind === "video" ? "video" : "html");
		if (kind === "image" && get().imageUrl) URL.revokeObjectURL(get().imageUrl);
		if (kind === "video" && get().videoUrl) URL.revokeObjectURL(get().videoUrl);
		const wallpaper = get().wallpaper;
		const drop = kind === "image" && wallpaper === "user-image" || kind === "video" && wallpaper === "user-video" || kind === "html" && wallpaper === "user-html";
		set({
			imageUrl: kind === "image" ? null : get().imageUrl,
			videoUrl: kind === "video" ? null : get().videoUrl,
			html: kind === "html" ? "" : get().html,
			userImageHasAlpha: kind === "image" ? false : get().userImageHasAlpha,
			wallpaper: drop ? "qum" : wallpaper,
			depth: drop ? true : get().depth,
			showClock: true
		});
	}
}), {
	name: "qatlam-v1",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? memoryStorage() : localStorage),
	partialize: (state) => ({
		wallpaper: state.wallpaper,
		font: state.font,
		weight: state.weight,
		scale: state.scale,
		color: state.color,
		shadow: state.shadow,
		seconds: state.seconds,
		showDate: state.showDate,
		showClock: state.showClock,
		clockY: state.clockY,
		depth: state.depth,
		maskX: state.maskX,
		maskY: state.maskY,
		maskW: state.maskW,
		maskH: state.maskH,
		feather: state.feather,
		userImageHasAlpha: state.userImageHasAlpha
	})
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function pad(n) {
	return String(n).padStart(2, "0");
}
function ClockFace() {
	const font = useQatlam((s) => s.font);
	const weight = useQatlam((s) => s.weight);
	const scale = useQatlam((s) => s.scale);
	const color = useQatlam((s) => s.color);
	const shadow = useQatlam((s) => s.shadow);
	const seconds = useQatlam((s) => s.seconds);
	const showDate = useQatlam((s) => s.showDate);
	const showClock = useQatlam((s) => s.showClock);
	const clockY = useQatlam((s) => s.clockY);
	const editing = useQatlam((s) => s.editing);
	const setClockY = useQatlam((s) => s.setClockY);
	const [now, setNow] = (0, import_react.useState)(null);
	const drag = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const tick = () => setNow(/* @__PURE__ */ new Date());
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	if (!showClock) return null;
	const family = FONTS.find((item) => item.id === font)?.family ?? "var(--font-outfit)";
	const date = now ? `${DAYS[now.getDay()]}, ${now.getDate()}-${MONTHS[now.getMonth()]}` : "——";
	const hh = now ? pad(now.getHours()) : "09";
	const mm = now ? pad(now.getMinutes()) : "41";
	const ss = now ? pad(now.getSeconds()) : "00";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("absolute left-0 right-0 z-20 flex flex-col items-center px-6 text-center select-none", editing && "clock-editing"),
		style: {
			top: `${clockY}%`,
			fontFamily: family,
			fontWeight: weight,
			fontSize: `clamp(4.25rem, ${scale * 22}vw, ${scale * 8.25}rem)`,
			color: clockCssColor(color),
			textShadow: shadow ? "0 0.06em 0.32em rgba(0,0,0,0.55)" : "none"
		},
		role: editing ? "slider" : void 0,
		"aria-label": "Soat joyi",
		"aria-valuemin": editing ? 6 : void 0,
		"aria-valuemax": editing ? 34 : void 0,
		"aria-valuenow": editing ? Math.round(clockY) : void 0,
		tabIndex: editing ? 0 : void 0,
		onKeyDown: (event) => {
			if (!editing) return;
			if (event.key === "ArrowUp") setClockY(clockY - 2);
			if (event.key === "ArrowDown") setClockY(clockY + 2);
		},
		onPointerDown: (event) => {
			if (!editing) return;
			event.currentTarget.setPointerCapture(event.pointerId);
			drag.current = {
				y: event.clientY,
				clock: clockY
			};
		},
		onPointerMove: (event) => {
			if (!drag.current) return;
			const next = drag.current.clock + (event.clientY - drag.current.y) / window.innerHeight * 100;
			setClockY(next);
		},
		onPointerUp: () => {
			drag.current = null;
		},
		children: [showDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "clock-date",
			children: date
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("time", {
			className: "clock-time",
			dateTime: now ? now.toISOString() : void 0,
			children: [
				hh,
				":",
				mm,
				seconds ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "clock-seconds",
					children: ss
				}) : null
			]
		})]
	});
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function bez(a, b, c, d, t) {
	const u = 1 - t;
	return u * u * u * a + 3 * u * u * t * b + 3 * u * t * t * c + t * t * t * d;
}
var GLYPHS = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓ012345789";
function drawMatrix(ctx, w, h, t) {
	ctx.fillStyle = "#020403";
	ctx.fillRect(0, 0, w, h);
	const size = Math.max(12, Math.round(w / 26));
	ctx.font = `500 ${size}px ui-monospace, monospace`;
	ctx.textBaseline = "top";
	const cols = Math.ceil(w / size);
	for (let c = 0; c < cols; c++) {
		const rnd = mulberry32(c * 997 + 13);
		const speed = 36 + rnd() * 80;
		const offset = rnd() * h;
		const trail = 8 + Math.floor(rnd() * 10);
		const head = (t * speed + offset) % (h + size * trail);
		for (let i = 0; i < trail; i++) {
			const y = head - i * size;
			if (y < -size || y > h) continue;
			const glyph = GLYPHS.charAt((c * 13 + i * 3 + Math.floor(t * (i === 0 ? 9 : 1.5))) % 44);
			const k = 1 - i / trail;
			ctx.fillStyle = i === 0 ? "#f3fff6" : `rgba(${Math.round(70 + 50 * k)}, ${Math.round(170 + 70 * k)}, ${Math.round(110 + 30 * k)}, ${.18 + k * .82})`;
			ctx.fillText(glyph, c * size, y);
		}
	}
}
function drawAurora(ctx, w, h, t) {
	const g = ctx.createLinearGradient(0, 0, 0, h);
	g.addColorStop(0, "#07060a");
	g.addColorStop(.5, "#0d1412");
	g.addColorStop(1, "#120e0b");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, w, h);
	const rnd = mulberry32(3);
	for (let i = 0; i < 70; i++) {
		const x = rnd() * w;
		const y = rnd() * h * .5;
		ctx.fillStyle = `rgba(244,236,227,${.18 * (.35 + .65 * (.5 + .5 * Math.sin(t * 1.4 + i)))})`;
		ctx.fillRect(x, y, 1.4, 1.4);
	}
	for (const b of [
		{
			y: .3,
			color: "rgba(88, 176, 138, 0.38)",
			amp: .055,
			ph: 0
		},
		{
			y: .38,
			color: "rgba(227, 154, 82, 0.2)",
			amp: .04,
			ph: 1.3
		},
		{
			y: .34,
			color: "rgba(186, 214, 196, 0.22)",
			amp: .07,
			ph: 2.1
		}
	]) {
		const base = h * b.y;
		ctx.beginPath();
		ctx.moveTo(0, h);
		for (let x = 0; x <= w; x += 8) {
			const y = base + Math.sin(x * .008 + t * .32 + b.ph) * h * b.amp + Math.sin(x * .021 - t * .45 + b.ph) * h * .018;
			ctx.lineTo(x, y);
		}
		ctx.lineTo(w, h);
		ctx.closePath();
		const lg = ctx.createLinearGradient(0, base - h * .14, 0, base + h * .28);
		lg.addColorStop(0, "rgba(0,0,0,0)");
		lg.addColorStop(.5, b.color);
		lg.addColorStop(1, "rgba(0,0,0,0)");
		ctx.fillStyle = lg;
		ctx.fill();
	}
}
function drawStars(ctx, w, h, t) {
	ctx.fillStyle = "#07060a";
	ctx.fillRect(0, 0, w, h);
	const ng = ctx.createRadialGradient(w * .68, h * .28, 0, w * .68, h * .28, w * .75);
	ng.addColorStop(0, "rgba(227,154,82,0.16)");
	ng.addColorStop(.45, "rgba(36,24,18,0.25)");
	ng.addColorStop(1, "rgba(0,0,0,0)");
	ctx.fillStyle = ng;
	ctx.fillRect(0, 0, w, h);
	const rnd = mulberry32(11);
	for (let i = 0; i < 130; i++) {
		const x = rnd() * w;
		const y = rnd() * h;
		const z = rnd();
		const s = z > .93 ? 2.1 : z > .72 ? 1.45 : .9;
		const tw = .4 + .6 * (.5 + .5 * Math.sin(t * (.7 + z) + i));
		ctx.fillStyle = z > .86 ? `rgba(227,154,82,${tw})` : `rgba(244,236,227,${.2 + .75 * tw * z})`;
		ctx.beginPath();
		ctx.arc(x, y, s, 0, Math.PI * 2);
		ctx.fill();
	}
}
function drawEmbers(ctx, w, h, t) {
	const g = ctx.createLinearGradient(0, 0, 0, h);
	g.addColorStop(0, "#07060a");
	g.addColorStop(1, "#1c0e09");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, w, h);
	const glow = ctx.createRadialGradient(w * .5, h * .92, 0, w * .5, h * .92, h * .45);
	glow.addColorStop(0, "rgba(180,70,24,0.35)");
	glow.addColorStop(1, "rgba(0,0,0,0)");
	ctx.fillStyle = glow;
	ctx.fillRect(0, 0, w, h);
	const rnd = mulberry32(21);
	for (let i = 0; i < 64; i++) {
		const x0 = rnd() * w;
		const speed = 18 + rnd() * 46;
		const phase = rnd();
		const size = 1.2 + rnd() * 2.4;
		const amber = 70 + Math.floor(rnd() * 90);
		const y = h + 20 - (t * speed + phase * h) % (h + 50);
		const x = x0 + Math.sin(t * .7 + i) * 10;
		const life = Math.min(1, Math.max(0, y / h));
		ctx.beginPath();
		ctx.fillStyle = `rgba(227,${amber},42,${.12 + (1 - life) * .75})`;
		ctx.arc(x, y, size * (.6 + (1 - life)), 0, Math.PI * 2);
		ctx.fill();
	}
}
function drawBokeh(ctx, w, h, t, seed) {
	ctx.fillStyle = "#0c0a09";
	ctx.fillRect(0, 0, w, h);
	const vg = ctx.createRadialGradient(w * .45, h * .32, 0, w * .5, h * .4, w * .85);
	vg.addColorStop(0, "#2c1d14");
	vg.addColorStop(1, "#0c0a09");
	ctx.fillStyle = vg;
	ctx.fillRect(0, 0, w, h);
	const rnd = mulberry32(seed);
	for (let i = 0; i < 26; i++) {
		const x = rnd() * w;
		const y = rnd() * h;
		const r = 14 + rnd() * 46;
		const drift = Math.sin(t * .28 + i) * 8;
		const amber = rnd() > .42;
		const cg = ctx.createRadialGradient(x + drift, y, 0, x + drift, y, r);
		cg.addColorStop(0, amber ? "rgba(227,154,82,0.3)" : "rgba(244,236,227,0.12)");
		cg.addColorStop(1, "rgba(0,0,0,0)");
		ctx.fillStyle = cg;
		ctx.beginPath();
		ctx.arc(x + drift, y, r, 0, Math.PI * 2);
		ctx.fill();
	}
}
function drawNiholFront(ctx, w, h, t) {
	const sway = Math.sin(t * .6) * w * .012;
	const x0 = w * 1.04;
	const y0 = h * .96;
	const x1 = w * .84;
	const y1 = h * .62;
	const x2 = w * .6 + sway;
	const y2 = h * .34;
	const x3 = w * .22 + sway * 1.3;
	const y3 = h * .06;
	ctx.lineCap = "round";
	ctx.lineJoin = "round";
	ctx.beginPath();
	ctx.moveTo(x0, y0);
	ctx.bezierCurveTo(x1, y1, x2, y2, x3, y3);
	ctx.strokeStyle = "#2a2418";
	ctx.lineWidth = Math.max(2.5, w * .018);
	ctx.stroke();
	ctx.strokeStyle = "#6a5b45";
	ctx.lineWidth = Math.max(1, w * .004);
	ctx.stroke();
	for (let i = 0; i < 18; i++) {
		const t0 = .06 + i / 18 * .9;
		const x = bez(x0, x1, x2, x3, t0);
		const y = bez(y0, y1, y2, y3, t0);
		const side = i % 2 === 0 ? 1 : -1;
		const ax0 = bez(x0, x1, x2, x3, Math.max(0, t0 - .02));
		const ax1 = bez(x0, x1, x2, x3, Math.min(1, t0 + .02));
		const ay0 = bez(y0, y1, y2, y3, Math.max(0, t0 - .02));
		const ay1 = bez(y0, y1, y2, y3, Math.min(1, t0 + .02));
		const ang = Math.atan2(ay1 - ay0, ax1 - ax0) + side * (.85 + i % 3 * .18);
		const len = w * (.055 + (1 - t0) * .07);
		ctx.save();
		ctx.translate(x, y);
		ctx.rotate(ang);
		ctx.beginPath();
		ctx.ellipse(len * .46, 0, len * .48, len * .16, 0, 0, Math.PI * 2);
		const lg = ctx.createLinearGradient(0, 0, len, 0);
		const dark = i % 3 === 0;
		lg.addColorStop(0, dark ? "#3c4426" : "#556332");
		lg.addColorStop(.55, dark ? "#8d9758" : "#c3c98a");
		lg.addColorStop(1, "#e4e2c2");
		ctx.fillStyle = lg;
		ctx.fill();
		ctx.beginPath();
		ctx.moveTo(len * .12, 0);
		ctx.lineTo(len * .86, 0);
		ctx.strokeStyle = "rgba(36,42,18,0.4)";
		ctx.lineWidth = 1;
		ctx.stroke();
		ctx.restore();
	}
}
function drawOrchidFront(ctx, w, h, t) {
	const sway = Math.sin(t * .5) * w * .01;
	const x0 = w * .16;
	const y0 = h * 1.02;
	const x1 = w * .1;
	const y1 = h * .66;
	const x2 = w * .32 + sway;
	const y2 = h * .38;
	const x3 = w * .46 + sway;
	const y3 = h * .2;
	ctx.lineCap = "round";
	ctx.beginPath();
	ctx.moveTo(x0, y0);
	ctx.bezierCurveTo(x1, y1, x2, y2, x3, y3);
	ctx.strokeStyle = "#1b3a28";
	ctx.lineWidth = Math.max(2, w * .013);
	ctx.stroke();
	for (const side of [-1, 1]) {
		const t0 = .42;
		ctx.save();
		ctx.translate(bez(x0, x1, x2, x3, t0), bez(y0, y1, y2, y3, t0));
		ctx.rotate(side * 1.15);
		ctx.beginPath();
		ctx.ellipse(w * .07, 0, w * .09, w * .016, 0, 0, Math.PI * 2);
		ctx.fillStyle = side < 0 ? "#245036" : "#326848";
		ctx.fill();
		ctx.restore();
	}
	ctx.save();
	ctx.translate(x3, y3);
	for (let i = 0; i < 5; i++) {
		ctx.save();
		ctx.rotate(i / 5 * Math.PI * 2 - Math.PI / 2);
		ctx.beginPath();
		ctx.ellipse(w * .055, 0, w * .072, w * .03, 0, 0, Math.PI * 2);
		ctx.fillStyle = i % 2 === 0 ? "#fbf7f1" : "#f3ece2";
		ctx.fill();
		ctx.restore();
	}
	ctx.beginPath();
	ctx.ellipse(w * .01, w * .028, w * .042, w * .026, .5, 0, Math.PI * 2);
	ctx.fillStyle = "#f4e4c8";
	ctx.fill();
	ctx.beginPath();
	ctx.arc(0, 0, w * .016, 0, Math.PI * 2);
	ctx.fillStyle = "#e39a52";
	ctx.fill();
	ctx.restore();
}
function drawQumBack(ctx, w, h, t) {
	const g = ctx.createLinearGradient(0, 0, 0, h);
	g.addColorStop(0, "#07060a");
	g.addColorStop(.38, "#1a120e");
	g.addColorStop(.58, "#6a3b22");
	g.addColorStop(.66, "#d08848");
	g.addColorStop(1, "#24140e");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, w, h);
	const rnd = mulberry32(5);
	for (let i = 0; i < 48; i++) {
		const x = rnd() * w;
		const y = rnd() * h * .42;
		ctx.fillStyle = `rgba(244,236,227,${.55 * (.4 + .6 * (.5 + .5 * Math.sin(t * 1.2 + i)))})`;
		ctx.fillRect(x, y, 1.3, 1.3);
	}
	const mx = w * .73;
	const my = h * .22;
	const mr = Math.min(w, h) * .105;
	const mg = ctx.createRadialGradient(mx - mr * .2, my - mr * .2, mr * .2, mx, my, mr * 2.6);
	mg.addColorStop(0, "rgba(255,244,230,0.95)");
	mg.addColorStop(.28, "rgba(243,214,170,0.45)");
	mg.addColorStop(1, "rgba(0,0,0,0)");
	ctx.fillStyle = mg;
	ctx.beginPath();
	ctx.arc(mx, my, mr * 2.6, 0, Math.PI * 2);
	ctx.fill();
	ctx.beginPath();
	ctx.arc(mx, my, mr, 0, Math.PI * 2);
	ctx.fillStyle = "#f7f0e6";
	ctx.fill();
	ctx.beginPath();
	ctx.arc(mx - mr * .28, my - mr * .22, mr * .22, 0, Math.PI * 2);
	ctx.fillStyle = "rgba(210,190,160,0.28)";
	ctx.fill();
}
function duneY(x, w, h) {
	const nx = x / w - .48;
	const peak = Math.exp(-(nx / .58) * (nx / .58));
	return h * .8 - peak * h * .58 + Math.sin(x * .035) * h * .008;
}
function drawQumFront(ctx, w, h) {
	ctx.beginPath();
	ctx.moveTo(0, h);
	for (let x = 0; x <= w; x += 3) ctx.lineTo(x, duneY(x, w, h));
	ctx.lineTo(w, h);
	ctx.closePath();
	const g = ctx.createLinearGradient(0, h * .18, 0, h);
	g.addColorStop(0, "#5a4030");
	g.addColorStop(.08, "#2a1c14");
	g.addColorStop(1, "#0c0908");
	ctx.fillStyle = g;
	ctx.fill();
	const rnd = mulberry32(44);
	ctx.save();
	ctx.clip();
	for (let i = 0; i < 180; i++) {
		ctx.fillStyle = rnd() > .5 ? "rgba(255,220,180,0.05)" : "rgba(0,0,0,0.18)";
		ctx.fillRect(rnd() * w, h * .2 + rnd() * h * .8, 1.5, 1.5);
	}
	ctx.restore();
	ctx.beginPath();
	for (let x = 0; x <= w; x += 3) {
		const y = duneY(x, w, h);
		if (x === 0) ctx.moveTo(x, y);
		else ctx.lineTo(x, y);
	}
	ctx.strokeStyle = "rgba(227,170,110,0.45)";
	ctx.lineWidth = 1.5;
	ctx.stroke();
}
function drawRavoqBack(ctx, w, h, t) {
	ctx.fillStyle = "#140e0b";
	ctx.fillRect(0, 0, w, h);
	const g = ctx.createRadialGradient(w / 2, h * .48, 0, w / 2, h * .48, w * .72);
	g.addColorStop(0, "#f2c79a");
	g.addColorStop(.22, "#c47a3a");
	g.addColorStop(.5, "#5a3018");
	g.addColorStop(1, "#140e0b");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, w, h);
	const rnd = mulberry32(8);
	for (let i = 0; i < 28; i++) {
		const x = w * .28 + rnd() * w * .44;
		const y = h * .18 + rnd() * h * .5;
		ctx.fillStyle = `rgba(255,236,210,${.28 * (.3 + .7 * (.5 + .5 * Math.sin(t * .8 + i)))})`;
		ctx.beginPath();
		ctx.arc(x, y, 1.2, 0, Math.PI * 2);
		ctx.fill();
	}
}
function drawRavoqFront(ctx, w, h) {
	ctx.fillStyle = "#1b140f";
	ctx.fillRect(0, 0, w, h);
	const rnd = mulberry32(2);
	for (let i = 0; i < 360; i++) {
		ctx.fillStyle = rnd() > .55 ? "rgba(255,220,180,0.045)" : "rgba(0,0,0,0.16)";
		ctx.fillRect(rnd() * w, rnd() * h, 2, 2);
	}
	const cx = w / 2;
	const cy = h * .5;
	const rx = w * .3;
	const ry = h * .3;
	ctx.globalCompositeOperation = "destination-out";
	ctx.beginPath();
	ctx.moveTo(cx - rx, h + 2);
	ctx.lineTo(cx - rx, cy);
	ctx.ellipse(cx, cy, rx, ry, 0, Math.PI, 0);
	ctx.lineTo(cx + rx, h + 2);
	ctx.closePath();
	ctx.fill();
	ctx.globalCompositeOperation = "source-over";
	ctx.beginPath();
	ctx.moveTo(cx - rx, h);
	ctx.lineTo(cx - rx, cy);
	ctx.ellipse(cx, cy, rx, ry, 0, Math.PI, 0);
	ctx.strokeStyle = "rgba(227,154,82,0.5)";
	ctx.lineWidth = Math.max(2, w * .012);
	ctx.stroke();
}
function drawSeaBack(ctx, w, h, t) {
	const g = ctx.createLinearGradient(0, 0, 0, h);
	g.addColorStop(0, "#070a10");
	g.addColorStop(.4, "#152433");
	g.addColorStop(.5, "#e0a36a");
	g.addColorStop(.54, "#1a303c");
	g.addColorStop(1, "#07090c");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, w, h);
	ctx.fillStyle = "rgba(244,220,190,0.12)";
	ctx.fillRect(w * .46, h * .52, w * .06, h * .28);
	ctx.strokeStyle = "rgba(244,236,227,0.09)";
	ctx.lineWidth = 1;
	for (let i = 0; i < 9; i++) {
		ctx.beginPath();
		const yb = h * (.58 + i * .045);
		for (let x = 0; x <= w; x += 8) {
			const y = yb + Math.sin(x * .02 + t * .55 + i) * 3;
			if (x === 0) ctx.moveTo(x, y);
			else ctx.lineTo(x, y);
		}
		ctx.stroke();
	}
}
function drawSeaFront(ctx, w, h) {
	ctx.beginPath();
	ctx.moveTo(w * .58, h + 4);
	ctx.lineTo(w * .66, h * .62);
	ctx.lineTo(w * .74, h * .28);
	ctx.lineTo(w * .8, h * .15);
	ctx.lineTo(w * .88, h * .22);
	ctx.lineTo(w * .93, h * .4);
	ctx.lineTo(w * 1.02, h * .34);
	ctx.lineTo(w * 1.02, h + 4);
	ctx.closePath();
	const g = ctx.createLinearGradient(w * .7, h * .15, w * .85, h);
	g.addColorStop(0, "#2a241c");
	g.addColorStop(.2, "#121418");
	g.addColorStop(1, "#07080a");
	ctx.fillStyle = g;
	ctx.fill();
	ctx.strokeStyle = "rgba(227,154,82,0.28)";
	ctx.lineWidth = 1.25;
	ctx.stroke();
}
function drawRainBack(ctx, w, h, t) {
	ctx.fillStyle = "#08090c";
	ctx.fillRect(0, 0, w, h);
	const rnd = mulberry32(15);
	for (let i = 0; i < 20; i++) {
		const x = rnd() * w;
		const y = rnd() * h;
		const r = 10 + rnd() * 34;
		const cg = ctx.createRadialGradient(x, y, 0, x, y, r);
		cg.addColorStop(0, rnd() > .5 ? "rgba(227,154,82,0.34)" : "rgba(210,218,226,0.16)");
		cg.addColorStop(1, "rgba(0,0,0,0)");
		ctx.fillStyle = cg;
		ctx.beginPath();
		ctx.arc(x, y, r, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.strokeStyle = "rgba(226,232,240,0.2)";
	ctx.lineWidth = 1;
	const rnd2 = mulberry32(16);
	for (let i = 0; i < 70; i++) {
		const x = rnd2() * w;
		const len = 12 + rnd2() * 16;
		const speed = 90 + rnd2() * 110;
		const y = (rnd2() * h + t * speed) % (h + 30) - 20;
		ctx.beginPath();
		ctx.moveTo(x, y);
		ctx.lineTo(x - 1.5, y + len);
		ctx.stroke();
	}
}
function drawRainFront(ctx, w, h) {
	const x = w * .8;
	ctx.strokeStyle = "#07080c";
	ctx.fillStyle = "#07080c";
	ctx.lineCap = "round";
	ctx.lineWidth = Math.max(5, w * .022);
	ctx.beginPath();
	ctx.moveTo(x, h + 8);
	ctx.lineTo(x, h * .12);
	ctx.stroke();
	ctx.beginPath();
	ctx.moveTo(x, h * .15);
	ctx.quadraticCurveTo(x + w * .02, h * .1, x + w * .11, h * .16);
	ctx.stroke();
	ctx.beginPath();
	ctx.ellipse(x + w * .1, h * .175, w * .05, w * .03, .1, 0, Math.PI * 2);
	ctx.fill();
}
function ribbon(ctx, w, h, t, y0, amp, color, width, phase) {
	ctx.beginPath();
	for (let x = -10; x <= w + 10; x += 6) {
		const y = h * y0 + Math.sin(x * .0075 + t * .35 + phase) * h * amp + Math.sin(x * .016 - t * .22 + phase) * h * amp * .35;
		if (x === -10) ctx.moveTo(x, y);
		else ctx.lineTo(x, y);
	}
	ctx.strokeStyle = color;
	ctx.lineWidth = width;
	ctx.lineCap = "round";
	ctx.lineJoin = "round";
	ctx.stroke();
}
function drawSilkBack(ctx, w, h, t) {
	ctx.fillStyle = "#100e0c";
	ctx.fillRect(0, 0, w, h);
	ribbon(ctx, w, h, t, .58, .07, "rgba(227,154,82,0.16)", h * .11, 0);
	ribbon(ctx, w, h, t, .72, .045, "rgba(244,236,227,0.06)", h * .07, 1.7);
	ribbon(ctx, w, h, t, .42, .06, "rgba(90,48,28,0.4)", h * .09, 2.4);
}
function drawSilkFront(ctx, w, h, t) {
	ribbon(ctx, w, h, t, .25, .045, "rgba(196,112,52,0.94)", Math.max(16, h * .042), .5);
	ribbon(ctx, w, h, t, .25, .045, "rgba(255,236,214,0.38)", Math.max(4, h * .01), .5);
}
function drawBlackHoleThumb(ctx, w, h) {
	ctx.fillStyle = "#07060a";
	ctx.fillRect(0, 0, w, h);
	const cx = w / 2;
	const cy = h * .46;
	const r = w * .32;
	const g = ctx.createRadialGradient(cx, cy, r * .15, cx, cy, r * 1.7);
	g.addColorStop(0, "#000");
	g.addColorStop(.42, "#000");
	g.addColorStop(.52, "#f0c08a");
	g.addColorStop(.66, "#8a3a12");
	g.addColorStop(1, "rgba(0,0,0,0)");
	ctx.fillStyle = g;
	ctx.beginPath();
	ctx.arc(cx, cy, r * 1.7, 0, Math.PI * 2);
	ctx.fill();
}
function drawScene(id, layer, ctx, w, h, t) {
	if (layer === "front") {
		if (id === "nihol") drawNiholFront(ctx, w, h, t);
		else if (id === "orxideya") drawOrchidFront(ctx, w, h, t);
		else if (id === "qum") drawQumFront(ctx, w, h);
		else if (id === "ravoq") drawRavoqFront(ctx, w, h);
		else if (id === "dengiz") drawSeaFront(ctx, w, h);
		else if (id === "yomgir") drawRainFront(ctx, w, h);
		else if (id === "ipak") drawSilkFront(ctx, w, h, t);
		return;
	}
	if (id === "matritsa") drawMatrix(ctx, w, h, t);
	else if (id === "aurora") drawAurora(ctx, w, h, t);
	else if (id === "yulduz") drawStars(ctx, w, h, t);
	else if (id === "chog") drawEmbers(ctx, w, h, t);
	else if (id === "nihol" || id === "orxideya") drawBokeh(ctx, w, h, t, id === "nihol" ? 31 : 37);
	else if (id === "qum") drawQumBack(ctx, w, h, t);
	else if (id === "ravoq") drawRavoqBack(ctx, w, h, t);
	else if (id === "dengiz") drawSeaBack(ctx, w, h, t);
	else if (id === "yomgir") drawRainBack(ctx, w, h, t);
	else drawSilkBack(ctx, w, h, t);
}
function drawPresetThumb(id, ctx, w, h) {
	if (id === "tuynuk") {
		drawBlackHoleThumb(ctx, w, h);
		return;
	}
	if (id === "user-image" || id === "user-video" || id === "user-html") return;
	drawScene(id, "back", ctx, w, h, 1.6);
	drawScene(id, "front", ctx, w, h, 1.6);
}
function useCanvasLoop(draw, active) {
	const ref = (0, import_react.useRef)(null);
	const drawRef = (0, import_react.useRef)(draw);
	drawRef.current = draw;
	(0, import_react.useEffect)(() => {
		if (!active) return;
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const resize = () => {
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			const w = canvas.clientWidth;
			const h = canvas.clientHeight;
			if (w < 2 || h < 2) return;
			canvas.width = Math.floor(w * dpr);
			canvas.height = Math.floor(h * dpr);
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		};
		const ro = new ResizeObserver(resize);
		ro.observe(canvas);
		resize();
		const frame = (now) => {
			const w = canvas.clientWidth;
			const h = canvas.clientHeight;
			if (w > 1 && h > 1) drawRef.current(ctx, w, h, now / 1e3);
			if (!reduced) raf = requestAnimationFrame(frame);
		};
		raf = requestAnimationFrame(frame);
		return () => {
			cancelAnimationFrame(raf);
			ro.disconnect();
		};
	}, [active]);
	return ref;
}
function SceneCanvas({ id, layer }) {
	const ref = useCanvasLoop((ctx, w, h, t) => {
		if (layer === "front") ctx.clearRect(0, 0, w, h);
		drawScene(id, layer, ctx, w, h, t);
	}, true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		className: "pointer-events-none absolute inset-0 h-full w-full",
		"aria-hidden": true
	});
}
function WallpaperThumb({ id }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const dpr = 2;
		const w = 80;
		const h = 120;
		canvas.width = 160;
		canvas.height = 240;
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		drawPresetThumb(id, ctx, w, h);
	}, [id]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		className: "h-full w-full",
		"aria-hidden": true
	});
}
function Toggle({ label, on, onChange, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		role: "switch",
		"aria-checked": on,
		disabled,
		onClick: () => onChange(!on),
		className: "flex min-h-11 w-full items-center justify-between gap-4 py-1 text-left text-sm text-ink disabled:opacity-40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("relative h-7 w-12 shrink-0 rounded-full", on && !disabled ? "bg-amber" : "bg-line"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 left-0.5 size-6 rounded-full bg-ink transition-transform duration-200", on && !disabled && "translate-x-5") })
		})]
	});
}
function Slider({ label, value, min, max, step, display, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1 text-sm text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center justify-between text-mute",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums text-ink",
				children: display
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "range",
			type: "range",
			min,
			max,
			step,
			value,
			onChange: (event) => onChange(Number(event.target.value))
		})]
	});
}
function PresetButton({ id, name }) {
	const current = useQatlam((s) => s.wallpaper);
	const select = useQatlam((s) => s.selectWallpaper);
	const selected = current === id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": selected,
		onClick: () => select(id),
		className: "flex w-16 shrink-0 flex-col gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("block h-24 w-16 overflow-hidden rounded-2xl border", selected ? "border-amber" : "border-line"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WallpaperThumb, { id })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("truncate text-center text-xs", selected ? "text-ink" : "text-mute"),
			children: name
		})]
	});
}
function EditorSheet() {
	const editing = useQatlam((s) => s.editing);
	const setEditing = useQatlam((s) => s.setEditing);
	const [tab, setTab] = (0, import_react.useState)("fon");
	const imageRef = (0, import_react.useRef)(null);
	const videoRef = (0, import_react.useRef)(null);
	const htmlRef = (0, import_react.useRef)(null);
	const [draft, setDraft] = (0, import_react.useState)("");
	const wallpaper = useQatlam((s) => s.wallpaper);
	const font = useQatlam((s) => s.font);
	const weight = useQatlam((s) => s.weight);
	const scale = useQatlam((s) => s.scale);
	const color = useQatlam((s) => s.color);
	const shadow = useQatlam((s) => s.shadow);
	const seconds = useQatlam((s) => s.seconds);
	const showDate = useQatlam((s) => s.showDate);
	const showClock = useQatlam((s) => s.showClock);
	const clockY = useQatlam((s) => s.clockY);
	const depth = useQatlam((s) => s.depth);
	const maskX = useQatlam((s) => s.maskX);
	const maskY = useQatlam((s) => s.maskY);
	const maskW = useQatlam((s) => s.maskW);
	const maskH = useQatlam((s) => s.maskH);
	const feather = useQatlam((s) => s.feather);
	const alpha = useQatlam((s) => s.userImageHasAlpha);
	const imageUrl = useQatlam((s) => s.imageUrl);
	const videoUrl = useQatlam((s) => s.videoUrl);
	const html = useQatlam((s) => s.html);
	const notice = useQatlam((s) => s.notice);
	const setFont = useQatlam((s) => s.setFont);
	const setWeight = useQatlam((s) => s.setWeight);
	const setScale = useQatlam((s) => s.setScale);
	const setColor = useQatlam((s) => s.setColor);
	const setShadow = useQatlam((s) => s.setShadow);
	const setSeconds = useQatlam((s) => s.setSeconds);
	const setShowDate = useQatlam((s) => s.setShowDate);
	const setShowClock = useQatlam((s) => s.setShowClock);
	const setClockY = useQatlam((s) => s.setClockY);
	const setDepth = useQatlam((s) => s.setDepth);
	const setMask = useQatlam((s) => s.setMask);
	const useImageFile = useQatlam((s) => s.useImageFile);
	const useVideoFile = useQatlam((s) => s.useVideoFile);
	const useHtmlFile = useQatlam((s) => s.useHtmlFile);
	const useHtmlText = useQatlam((s) => s.useHtmlText);
	const useSampleHtml = useQatlam((s) => s.useSampleHtml);
	const clearUserMedia = useQatlam((s) => s.clearUserMedia);
	const live = WALLPAPERS.filter((item) => item.group === "live");
	const studio = WALLPAPERS.filter((item) => item.group === "studio");
	const photo = wallpaper === "user-image" || wallpaper === "user-video";
	const depthOk = hasSceneFront(wallpaper) || photo;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("sheet fixed inset-x-0 bottom-0 z-40 flex flex-col overflow-hidden rounded-t-3xl border border-line backdrop-blur-xl", editing ? "translate-y-0" : "pointer-events-none translate-y-full"),
		"aria-hidden": !editing,
		inert: !editing,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sticky top-0 z-10 border-b border-line bg-surface/90 px-5 pt-3 pb-3 backdrop-blur-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-lg font-medium text-balance text-ink",
					children: "Qatlam"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-mute",
					children: "Soatni rasm orqasiga qo‘ying"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setEditing(false),
					className: "rounded-full bg-amber px-4 py-2 text-sm font-medium text-void",
					children: "Tayyor"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-1 rounded-full bg-void p-1",
				role: "tablist",
				children: [
					["fon", "Fon"],
					["soat", "Soat"],
					["qatlam", "Qatlam"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": tab === id,
					onClick: () => setTab(id),
					className: cn("min-h-11 rounded-full text-sm", tab === id ? "bg-amber text-void" : "text-mute"),
					children: label
				}, id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "scroller flex flex-col gap-5 overflow-y-auto px-5 pt-4 pb-8",
			children: [
				notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-amber",
					children: notice
				}) : null,
				tab === "fon" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xs tracking-widest text-mute uppercase",
							children: "Jonli"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "scroller flex gap-3 overflow-x-auto pb-1",
							children: live.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetButton, {
								id: item.id,
								name: item.name
							}, item.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xs tracking-widest text-mute uppercase",
							children: "Studiya"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "scroller flex gap-3 overflow-x-auto pb-1",
							children: studio.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetButton, {
								id: item.id,
								name: item.name
							}, item.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xs tracking-widest text-mute uppercase",
								children: "O‘zingizniki"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => imageRef.current?.click(),
										className: "flex min-h-16 flex-col items-center justify-center gap-1 rounded-2xl border border-line text-xs text-ink",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {
											className: "size-4",
											"aria-hidden": true
										}), "Rasm"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => videoRef.current?.click(),
										className: "flex min-h-16 flex-col items-center justify-center gap-1 rounded-2xl border border-line text-xs text-ink",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, {
											className: "size-4",
											"aria-hidden": true
										}), "Video"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => htmlRef.current?.click(),
										className: "flex min-h-16 flex-col items-center justify-center gap-1 rounded-2xl border border-line text-xs text-ink",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Code, {
											className: "size-4",
											"aria-hidden": true
										}), "HTML"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: imageRef,
								type: "file",
								accept: "image/*",
								className: "hidden",
								onChange: (event) => {
									const file = event.target.files?.[0];
									event.target.value = "";
									if (file) useImageFile(file);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: videoRef,
								type: "file",
								accept: "video/*",
								className: "hidden",
								onChange: (event) => {
									const file = event.target.files?.[0];
									event.target.value = "";
									if (file) useVideoFile(file);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: htmlRef,
								type: "file",
								accept: ".html,text/html",
								className: "hidden",
								onChange: (event) => {
									const file = event.target.files?.[0];
									event.target.value = "";
									if (file) useHtmlFile(file);
								}
							}),
							imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-left text-sm text-mute",
								onClick: () => void clearUserMedia("image"),
								children: "Rasmni olib tashlash"
							}) : null,
							videoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-left text-sm text-mute",
								onClick: () => void clearUserMedia("video"),
								children: "Videoni olib tashlash"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex flex-col gap-2 text-sm text-ink",
								children: ["HTML kod", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: draft,
									onChange: (event) => setDraft(event.target.value),
									rows: 4,
									placeholder: "<html>… matritsa yoki qora tuynuk sahifasi",
									className: "resize-none rounded-2xl border border-line bg-void px-3 py-3 text-sm text-ink outline-none placeholder:text-mute"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => void useHtmlText(draft),
									className: "min-h-11 flex-1 rounded-full border border-line text-sm text-ink",
									children: "Kodni qo‘yish"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => void useSampleHtml(),
									className: "min-h-11 flex-1 rounded-full border border-amber text-sm text-amber",
									children: "Namuna: tuynuk"
								})]
							}),
							html ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-left text-sm text-mute",
								onClick: () => void clearUserMedia("html"),
								children: "HTML fonni olib tashlash"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs leading-relaxed text-pretty text-mute",
								children: "Telefon tizim fonini sayt almashtira olmaydi. Ilovani bosh ekranga qo‘shsangiz, ochilganda shu qulf ekrani turadi."
							})
						]
					})
				] }) : null,
				tab === "soat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "scroller flex gap-2 overflow-x-auto pb-1",
							children: FONTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": font === item.id,
								onClick: () => setFont(item.id),
								className: cn("min-h-11 shrink-0 rounded-full border px-4 text-sm", font === item.id ? "border-amber bg-amber text-void" : "border-line text-ink"),
								style: { fontFamily: item.family },
								children: item.label
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								[200, "Yupqa"],
								[400, "Oddiy"],
								[600, "Qalin"]
							].map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": weight === value,
								onClick: () => setWeight(value),
								className: cn("min-h-11 rounded-full border text-sm", weight === value ? "border-amber bg-amber text-void" : "border-line text-ink"),
								children: label
							}, value))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "O‘lcham",
							min: 70,
							max: 150,
							step: 1,
							value: Math.round(scale * 100),
							display: `${Math.round(scale * 100)}%`,
							onChange: (value) => setScale(value / 100)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Joyi",
							min: 6,
							max: 34,
							step: 1,
							value: Math.round(clockY),
							display: `${Math.round(clockY)}`,
							onChange: setClockY
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [[
								[
									"ink",
									"Oq",
									"var(--color-ink)"
								],
								[
									"silver",
									"Kumush",
									"var(--color-silver)"
								],
								[
									"amber",
									"Amber",
									"var(--color-amber)"
								]
							].map(([id, label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": label,
								"aria-pressed": color === id,
								onClick: () => setColor(id),
								className: cn("size-11 rounded-full border-2", color === id ? "border-amber" : "border-line"),
								style: { background: value }
							}, id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm text-mute",
								children: ["O‘z rangi", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "color",
									value: colorToHex(color),
									"aria-label": "O‘z rangi",
									onChange: (event) => setColor(event.target.value),
									className: "size-11 cursor-pointer rounded-full border border-line bg-void"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							label: "Sana",
							on: showDate,
							onChange: setShowDate
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							label: "Soniya",
							on: seconds,
							onChange: setSeconds
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							label: "Soya",
							on: shadow,
							onChange: setShadow
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							label: "Soatni ko‘rsatish",
							on: showClock,
							onChange: setShowClock
						})
					]
				}) : null,
				tab === "qatlam" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							label: "Soat rasm orqasida",
							on: depth,
							onChange: setDepth,
							disabled: !depthOk
						}),
						hasSceneFront(wallpaper) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-pretty text-mute",
							children: "Old qatlam — qum, ravoq, nihol — soat raqamlarini yopadi. Soatni ushlab sudrang yoki Joyi slayderini siljiting."
						}) : null,
						photo && !(wallpaper === "user-image" && alpha) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-pretty text-mute",
								children: "Niqobni odam yoki buyum ustiga qo‘ying. Shu joy soatning oldiga chiqadi — iPhone dagi kabi."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Markaz X",
								min: 10,
								max: 90,
								step: 1,
								value: maskX,
								display: `${Math.round(maskX)}`,
								onChange: (value) => setMask({ maskX: value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Markaz Y",
								min: 10,
								max: 90,
								step: 1,
								value: maskY,
								display: `${Math.round(maskY)}`,
								onChange: (value) => setMask({ maskY: value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Eni",
								min: 30,
								max: 120,
								step: 1,
								value: maskW,
								display: `${Math.round(maskW)}`,
								onChange: (value) => setMask({ maskW: value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Bo‘yi",
								min: 20,
								max: 100,
								step: 1,
								value: maskH,
								display: `${Math.round(maskH)}`,
								onChange: (value) => setMask({ maskH: value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Pat",
								min: 0,
								max: 40,
								step: 1,
								value: feather,
								display: `${Math.round(feather)}`,
								onChange: (value) => setMask({ feather: value })
							})
						] }) : null,
						wallpaper === "user-image" && alpha ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-pretty text-mute",
							children: "Shaffof PNG aniqlandi. Rasmning o‘zi soatni yopadi, bo‘sh joydan soat ko‘rinadi."
						}) : null,
						!depthOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-pretty text-mute",
							children: "Matritsa va qora tuynukda old qatlam yo‘q. Qumlar, ravoq yoki o‘z rasmingizda soat orqaga tushadi. HTML sahifa o‘z ekranini ko‘rsatadi — soatni alohida yoqishingiz mumkin."
						}) : null
					]
				}) : null
			]
		})]
	});
}
var BLACK_HOLE_VS = "attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}";
var BLACK_HOLE_FS = "\n#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nuniform vec2 uRes;uniform float uT,uFlash,uDim;\nfloat h2(vec2 p){p=fract(p*vec2(.1031,.1030));p+=dot(p,p.yx+33.33);return fract((p.x+p.y)*p.x);}\nfloat h3(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}\nfloat n3(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);\n return mix(mix(mix(h3(i),h3(i+vec3(1,0,0)),f.x),mix(h3(i+vec3(0,1,0)),h3(i+vec3(1,1,0)),f.x),f.y),\n            mix(mix(h3(i+vec3(0,0,1)),h3(i+vec3(1,0,1)),f.x),mix(h3(i+vec3(0,1,1)),h3(i+vec3(1,1,1)),f.x),f.y),f.z);}\nfloat fb(vec3 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*n3(p);p*=2.02;a*=.5;}return s;}\nvec3 stl(vec3 d,float sc,float th,float sz){\n vec3 q=d*sc,id=floor(q),f=fract(q)-.5;float h=h3(id);\n if(h<th)return vec3(0.);\n vec3 o=(vec3(h3(id+7.1),h3(id+13.7),h3(id+29.3))-.5)*.5;\n float dd=dot(f-o,f-o);\n float b=exp(-dd/(sz*sz))*(.25+1.1*pow(fract(h*57.3),3.));\n return mix(vec3(1.,.72,.5),vec3(.65,.78,1.),fract(h*91.7))*b;}\nvec3 sky(vec3 d){\n float hz=n3(d*2.6+3.1)*n3(d*5.3+9.)+.5*n3(d*11.);\n vec3 c=vec3(.0030,.0034,.0048)+hz*hz*vec3(.030,.022,.016);\n c+=stl(d,110.,.985,.11)*2.4+stl(d,330.,.975,.15)*1.2+stl(d,760.,.97,.22)*.8;\n return c;}\nvoid main(){\n float sc=min(uRes.x,uRes.y*.55);\n vec2 uv=(gl_FragCoord.xy-uRes*vec2(.5,.53))/sc;\n float cr=cos(.3),sr=sin(.3);\n vec2 w=vec2(cr*uv.x+sr*uv.y,-sr*uv.x+cr*uv.y);\n float e=.15;\n vec3 ro=vec3(0.,28.*sin(e),28.*cos(e));\n vec3 f=-normalize(ro),rt=normalize(cross(f,vec3(0.,1.,0.))),up=cross(rt,f);\n vec3 v=normalize(f+.42*(w.x*rt+w.y*up));\n vec3 p=ro;\n float hh=length(cross(p,v)),H2=hh*hh;\n vec3 col=vec3(0.);float tr=1.;bool hit=false,esc=false;\n for(int i=0;i<130;i++){\n  float r2=dot(p,p),r=sqrt(r2);\n  if(r<1.){hit=true;break;}\n  if(r>45.&&dot(p,v)>0.){esc=true;break;}\n  float dt=.06+.12*max(r-2.2,0.);\n  v=normalize(v-1.5*H2*p/(r2*r2*r)*dt);\n  vec3 pn=p+v*dt;\n  if(p.y*pn.y<0.){\n   vec3 q=mix(p,pn,p.y/(p.y-pn.y));\n   float rr=length(q.xz);\n   if(rr>3.&&rr<12.){\n    float ph=atan(q.z,q.x)+2.2/(rr*sqrt(rr))*uT*1.4;\n    float n1=fb(vec3(cos(ph)*3.,sin(ph)*3.,rr*16.));\n    float n2=fb(vec3(cos(ph+1.7)*7.,sin(ph+1.7)*7.,rr*40.+5.));\n    float dens=clamp((.55*n1+.45*n2-.22)*2.6,0.,1.);\n    float edge=smoothstep(3.,3.6,rr)*(1.-smoothstep(8.,12.,rr));\n    vec3 tg=normalize(vec3(-q.z,0.,q.x));\n    float beta=sqrt(.5/(rr-1.));\n    float dop=sqrt(1.-beta*beta)/(1.-beta*dot(tg,-v));\n    float ff=clamp(dop*sqrt(1.-1./rr),.25,2.2);\n    float T=pow(3./rr,.75)*ff;\n    vec3 cc=T*vec3(1.,.38+.45*T,.1+.6*T*T);\n    float I=pow(3./rr,2.2)*ff*ff*ff*(.35+1.6*dens)*1.5;\n    float al=edge*clamp(.2+dens*.9,0.,.95);\n    col+=tr*cc*I*al;tr*=1.-al;\n   }\n  }\n  p=pn;\n }\n if(!hit&&(esc||dot(p,p)>36.))col+=tr*sky(v);\n float ring=exp(-pow((hh-2.6)/.04,2.))*(.45+.55*clamp(dot(normalize(w+1e-5),vec2(-.6,-.8))*.5+.5,0.,1.));\n col+=ring*vec3(1.,.78,.5)*.9+vec3(1.,.55,.2)*.04*exp(-pow((hh-2.6)/.5,2.));\n col*=mix(1.,.72,uDim);\n col=col*(1.+uFlash*1.2)+uFlash*vec3(1.,.6,.3)*.5*exp(-dot(uv,uv)*5.);\n col*=1.-.35*smoothstep(.5,1.4,length(uv));\n col*=1.1;\n col=(col*(2.51*col+.03))/(col*(2.43*col+.59)+.14);\n col=pow(clamp(col,0.,1.),vec3(1./2.2));\n col+=(h2(gl_FragCoord.xy+uT)-.5)/255.;\n gl_FragColor=vec4(col,1.);\n}";
function BlackHole() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const gl = canvas.getContext("webgl", {
			antialias: false,
			alpha: false,
			powerPreference: "high-performance"
		});
		if (!gl) return;
		const compile = (type, src) => {
			const shader = gl.createShader(type);
			if (!shader) throw new Error("shader");
			gl.shaderSource(shader, src);
			gl.compileShader(shader);
			if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) || "compile");
			return shader;
		};
		let raf = 0;
		let observer = null;
		try {
			const program = gl.createProgram();
			if (!program) return;
			gl.attachShader(program, compile(gl.VERTEX_SHADER, BLACK_HOLE_VS));
			gl.attachShader(program, compile(gl.FRAGMENT_SHADER, BLACK_HOLE_FS));
			gl.linkProgram(program);
			if (!gl.getProgramParameter(program, gl.LINK_STATUS)) return;
			gl.useProgram(program);
			const buffer = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
			gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
				-1,
				-1,
				3,
				-1,
				-1,
				3
			]), gl.STATIC_DRAW);
			const loc = gl.getAttribLocation(program, "a");
			gl.enableVertexAttribArray(loc);
			gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
			const uRes = gl.getUniformLocation(program, "uRes");
			const uT = gl.getUniformLocation(program, "uT");
			const uFlash = gl.getUniformLocation(program, "uFlash");
			const uDim = gl.getUniformLocation(program, "uDim");
			let quality = 1;
			const resize = () => {
				const width = canvas.clientWidth || 1;
				const height = canvas.clientHeight || 1;
				let k = Math.min(window.devicePixelRatio || 1, 2) * quality;
				k = Math.min(k, Math.sqrt(12e6 / (width * height)));
				canvas.width = Math.max(2, Math.floor(width * k));
				canvas.height = Math.max(2, Math.floor(height * k));
				gl.viewport(0, 0, canvas.width, canvas.height);
			};
			observer = new ResizeObserver(resize);
			observer.observe(canvas);
			resize();
			const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
			let frames = 0;
			let acc = 0;
			let last = performance.now();
			const loop = (now) => {
				const dt = (now - last) / 1e3;
				last = now;
				acc += dt;
				frames += 1;
				if (frames % 40 === 0) {
					if (acc / 40 > .034 && quality > .55) {
						quality = Math.max(.55, quality - .12);
						resize();
					}
					acc = 0;
				}
				gl.uniform2f(uRes, canvas.width, canvas.height);
				gl.uniform1f(uT, reduced ? 8 : now / 1e3);
				gl.uniform1f(uFlash, 0);
				gl.uniform1f(uDim, 0);
				gl.drawArrays(gl.TRIANGLES, 0, 3);
				if (!reduced) raf = requestAnimationFrame(loop);
			};
			raf = requestAnimationFrame(loop);
		} catch (error) {
			console.error(error);
		}
		return () => {
			cancelAnimationFrame(raf);
			observer?.disconnect();
			gl.getExtension("WEBGL_lose_context")?.loseContext();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "bh-fallback absolute inset-0",
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref,
			className: "pointer-events-none absolute inset-0 h-full w-full",
			"aria-hidden": true
		})]
	});
}
var leadVideo = null;
function UserImage({ layer }) {
	const url = useQatlam((s) => s.imageUrl);
	const alpha = useQatlam((s) => s.userImageHasAlpha);
	const depth = useQatlam((s) => s.depth);
	const maskX = useQatlam((s) => s.maskX);
	const maskY = useQatlam((s) => s.maskY);
	const maskW = useQatlam((s) => s.maskW);
	const maskH = useQatlam((s) => s.maskH);
	const feather = useQatlam((s) => s.feather);
	if (!url) return null;
	if (layer === "front" && !depth) return null;
	if (layer === "back" && depth && alpha) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: url,
		alt: "",
		className: "pointer-events-none absolute inset-0 h-full w-full scale-110 object-cover opacity-80 blur-2xl"
	});
	if (layer === "front" && alpha) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: url,
		alt: "",
		className: "pointer-events-none absolute inset-0 h-full w-full object-cover"
	});
	if (layer === "front") {
		const image = `radial-gradient(ellipse ${maskW}% ${maskH}% at ${maskX}% ${maskY}%, #000 ${Math.max(8, 62 - feather)}%, transparent ${Math.min(98, 70 + feather * .35)}%)`;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: url,
			alt: "",
			className: "pointer-events-none absolute inset-0 h-full w-full object-cover",
			style: {
				WebkitMaskImage: image,
				maskImage: image
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: url,
		alt: "",
		className: "pointer-events-none absolute inset-0 h-full w-full object-cover"
	});
}
function UserVideo({ layer }) {
	const url = useQatlam((s) => s.videoUrl);
	const depth = useQatlam((s) => s.depth);
	const maskX = useQatlam((s) => s.maskX);
	const maskY = useQatlam((s) => s.maskY);
	const maskW = useQatlam((s) => s.maskW);
	const maskH = useQatlam((s) => s.maskH);
	const feather = useQatlam((s) => s.feather);
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const video = ref.current;
		if (!video) return;
		if (layer === "back") leadVideo = video;
		const play = () => void video.play().catch(() => {});
		play();
		const sync = () => {
			if (layer === "front" && leadVideo && Math.abs(video.currentTime - leadVideo.currentTime) > .25) video.currentTime = leadVideo.currentTime;
		};
		video.addEventListener("timeupdate", sync);
		window.addEventListener("pointerdown", play);
		return () => {
			video.removeEventListener("timeupdate", sync);
			window.removeEventListener("pointerdown", play);
			if (leadVideo === video) leadVideo = null;
		};
	}, [url, layer]);
	if (!url || layer === "front" && !depth) return null;
	const image = `radial-gradient(ellipse ${maskW}% ${maskH}% at ${maskX}% ${maskY}%, #000 ${Math.max(8, 62 - feather)}%, transparent ${Math.min(98, 70 + feather * .35)}%)`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
		ref,
		src: url,
		muted: true,
		loop: true,
		autoPlay: true,
		playsInline: true,
		className: "pointer-events-none absolute inset-0 h-full w-full object-cover",
		style: layer === "front" ? {
			WebkitMaskImage: image,
			maskImage: image
		} : void 0
	});
}
function UserHtml() {
	const html = useQatlam((s) => s.html);
	if (!html) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 flex items-center justify-center px-8 text-center text-mute",
		children: "HTML fayl yoki kod qo‘ying — masalan, qora tuynuk sahifasi."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
		title: "HTML fon",
		sandbox: "allow-scripts",
		srcDoc: html,
		className: "absolute inset-0 h-full w-full border-0 bg-void"
	});
}
function BackLayer({ id }) {
	if (id === "tuynuk") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlackHole, {});
	if (id === "user-html") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserHtml, {});
	if (id === "user-image") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserImage, { layer: "back" });
	if (id === "user-video") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserVideo, { layer: "back" });
	if (isScene(id)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SceneCanvas, {
		id,
		layer: "back"
	});
	return null;
}
function FrontLayer({ id }) {
	if (!useQatlam((s) => s.depth)) return null;
	if (id === "user-image") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserImage, { layer: "front" });
	if (id === "user-video") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserVideo, { layer: "front" });
	if (hasSceneFront(id) && isScene(id)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SceneCanvas, {
		id,
		layer: "front"
	});
	return null;
}
function useHydrateMedia() {
	(0, import_react.useEffect)(() => {
		let gone = false;
		const created = [];
		(async () => {
			try {
				await useQatlam.persist.rehydrate();
			} catch {}
			let image;
			let video;
			let html;
			try {
				[image, video, html] = await Promise.all([
					idbGet("image"),
					idbGet("video"),
					idbGet("html")
				]);
			} catch {}
			if (gone) return;
			const patch = { mediaReady: true };
			if (image instanceof Blob) {
				const url = URL.createObjectURL(image);
				created.push(url);
				patch.imageUrl = url;
			}
			if (video instanceof Blob) {
				const url = URL.createObjectURL(video);
				created.push(url);
				patch.videoUrl = url;
			}
			if (typeof html === "string") patch.html = html;
			useQatlam.setState(patch);
		})();
		return () => {
			gone = true;
			for (const url of created) URL.revokeObjectURL(url);
		};
	}, []);
}
function LockScreen() {
	useHydrateMedia();
	const editing = useQatlam((s) => s.editing);
	const setEditing = useQatlam((s) => s.setEditing);
	const wallpaper = useQatlam((s) => s.wallpaper);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key === "Escape") setEditing(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [setEditing]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "fixed inset-0 overflow-hidden bg-void text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "sr-only",
				children: "Qatlam — qulf ekrani"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLayer, { id: wallpaper })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "vignette pointer-events-none absolute inset-0 z-10",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockFace, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 z-30",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrontLayer, { id: wallpaper })
			}),
			editing ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setEditing(true),
				className: "fixed bottom-[max(1.25rem,env(safe-area-inset-bottom))] left-1/2 z-40 min-h-11 -translate-x-1/2 rounded-full border border-line bg-surface/75 px-5 text-sm text-ink backdrop-blur-md",
				children: "Sozlash"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditorSheet, {})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockScreen, {});
}
//#endregion
export { Home as component };
