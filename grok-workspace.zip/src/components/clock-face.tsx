import { useEffect, useRef, useState } from "react";
import { DAYS, FONTS, MONTHS, clockCssColor } from "@/lib/presets";
import { useQatlam } from "@/lib/store";
import { cn } from "@/lib/cn";

function pad(n: number) {
  return String(n).padStart(2, "0");
}

export function ClockFace() {
  const font = useQatlam((s) => s.font);
  const weight = useQatlam((s) => s.weight);
  const scale = useQatlam((s) => s.scale);
  const color = useQatlam((s) => s.color);
  const shadow = useQatlam((s) => s.shadow);
  const seconds = useQatlam((s) => s.seconds);
  const showDate = useQatlam((s) => s.showDate);
  const showClock = useQatlam((s) => s.showClock);
  const clockY = useQatlam((s) => s.clockY);
  const editing = useQatlam((s) => s.editing);
  const setClockY = useQatlam((s) => s.setClockY);
  const [now, setNow] = useState<Date | null>(null);
  const drag = useRef<{ y: number; clock: number } | null>(null);

  useEffect(() => {
    const tick = () => setNow(new Date());
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  if (!showClock) return null;

  const family = FONTS.find((item) => item.id === font)?.family ?? "var(--font-outfit)";
  const date = now ? `${DAYS[now.getDay()]}, ${now.getDate()}-${MONTHS[now.getMonth()]}` : "——";
  const hh = now ? pad(now.getHours()) : "09";
  const mm = now ? pad(now.getMinutes()) : "41";
  const ss = now ? pad(now.getSeconds()) : "00";

  return (
    <div
      className={cn(
        "absolute left-0 right-0 z-20 flex flex-col items-center px-6 text-center select-none",
        editing && "clock-editing",
      )}
      style={{
        top: `${clockY}%`,
        fontFamily: family,
        fontWeight: weight,
        fontSize: `clamp(4.25rem, ${scale * 22}vw, ${scale * 8.25}rem)`,
        color: clockCssColor(color),
        textShadow: shadow ? "0 0.06em 0.32em rgba(0,0,0,0.55)" : "none",
      }}
      role={editing ? "slider" : undefined}
      aria-label="Soat joyi"
      aria-valuemin={editing ? 6 : undefined}
      aria-valuemax={editing ? 34 : undefined}
      aria-valuenow={editing ? Math.round(clockY) : undefined}
      tabIndex={editing ? 0 : undefined}
      onKeyDown={(event) => {
        if (!editing) return;
        if (event.key === "ArrowUp") setClockY(clockY - 2);
        if (event.key === "ArrowDown") setClockY(clockY + 2);
      }}
      onPointerDown={(event) => {
        if (!editing) return;
        event.currentTarget.setPointerCapture(event.pointerId);
        drag.current = { y: event.clientY, clock: clockY };
      }}
      onPointerMove={(event) => {
        if (!drag.current) return;
        const next = drag.current.clock + ((event.clientY - drag.current.y) / window.innerHeight) * 100;
        setClockY(next);
      }}
      onPointerUp={() => {
        drag.current = null;
      }}
    >
      {showDate ? <span className="clock-date">{date}</span> : null}
      <time className="clock-time" dateTime={now ? now.toISOString() : undefined}>
        {hh}:{mm}
        {seconds ? <span className="clock-seconds">{ss}</span> : null}
      </time>
    </div>
  );
}
