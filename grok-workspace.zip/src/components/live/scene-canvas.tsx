import { useEffect, useRef } from "react";
import { type Layer, type SceneId, type WallpaperId } from "@/lib/presets";
import { drawPresetThumb, drawScene } from "@/components/live/scenes";
import { useCanvasLoop } from "@/components/live/use-canvas";

export function SceneCanvas({ id, layer }: { id: SceneId; layer: Layer }) {
  const ref = useCanvasLoop((ctx, w, h, t) => {
    if (layer === "front") ctx.clearRect(0, 0, w, h);
    drawScene(id, layer, ctx, w, h, t);
  }, true);
  return <canvas ref={ref} className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden />;
}

export function WallpaperThumb({ id }: { id: WallpaperId }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = 2;
    const w = 80;
    const h = 120;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawPresetThumb(id, ctx, w, h);
  }, [id]);
  return <canvas ref={ref} className="h-full w-full" aria-hidden />;
}
