import { useEffect, useRef } from "react";
import { BLACK_HOLE_FS, BLACK_HOLE_VS } from "@/components/live/black-hole-shader";

export function BlackHole() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const gl = canvas.getContext("webgl", {
      antialias: false,
      alpha: false,
      powerPreference: "high-performance",
    });
    if (!gl) return;

    const compile = (type: number, src: string) => {
      const shader = gl.createShader(type);
      if (!shader) throw new Error("shader");
      gl.shaderSource(shader, src);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        throw new Error(gl.getShaderInfoLog(shader) || "shader");
      }
      return shader;
    };

    let raf = 0;
    let observer: ResizeObserver | null = null;
    try {
      const program = gl.createProgram();
      if (!program) return;
      gl.attachShader(program, compile(gl.VERTEX_SHADER, BLACK_HOLE_VS));
      gl.attachShader(program, compile(gl.FRAGMENT_SHADER, BLACK_HOLE_FS));
      gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) return;
      gl.useProgram(program);
      const buffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(program, "a");
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      const uRes = gl.getUniformLocation(program, "uRes");
      const uT = gl.getUniformLocation(program, "uT");
      const uFlash = gl.getUniformLocation(program, "uFlash");
      const uDim = gl.getUniformLocation(program, "uDim");
      let quality = 1;

      const resize = () => {
        const width = canvas.clientWidth || 1;
        const height = canvas.clientHeight || 1;
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        let k = dpr * quality;
        k = Math.min(k, Math.sqrt(1.2e7 / (width * height)));
        canvas.width = Math.max(2, Math.floor(width * k));
        canvas.height = Math.max(2, Math.floor(height * k));
        gl.viewport(0, 0, canvas.width, canvas.height);
      };

      observer = new ResizeObserver(resize);
      observer.observe(canvas);
      resize();

      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      let frames = 0;
      let acc = 0;
      let last = performance.now();
      const loop = (now: number) => {
        const dt = (now - last) / 1000;
        last = now;
        acc += dt;
        frames += 1;
        if (frames % 40 === 0) {
          if (acc / 40 > 0.034 && quality > 0.55) {
            quality = Math.max(0.55, quality - 0.12);
            resize();
          }
          acc = 0;
        }
        gl.uniform2f(uRes, canvas.width, canvas.height);
        gl.uniform1f(uT, reduced ? 8 : now / 1000);
        gl.uniform1f(uFlash, 0);
        gl.uniform1f(uDim, 0);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
        if (!reduced) raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
    } catch (error) {
      console.error(error);
    }

    return () => {
      cancelAnimationFrame(raf);
      observer?.disconnect();
    };
  }, []);

  return (
    <div className="absolute inset-0">
      <div className="bh-fallback absolute inset-0" aria-hidden />
      <canvas ref={ref} className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden />
    </div>
  );
}
