import { type Layer, type SceneId, type WallpaperId } from "@/lib/presets";

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function bez(a: number, b: number, c: number, d: number, t: number) {
  const u = 1 - t;
  return u * u * u * a + 3 * u * u * t * b + 3 * u * t * t * c + t * t * t * d;
}

const GLYPHS = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓ012345789";

function drawMatrix(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  ctx.fillStyle = "#04140c";
  ctx.fillRect(0, 0, w, h);
  const size = Math.max(14, Math.round(w / 22));
  ctx.font = `500 ${size}px ui-monospace, monospace`;
  ctx.textBaseline = "top";
  const cols = Math.ceil(w / size);
  for (let c = 0; c < cols; c++) {
    const rnd = mulberry32(c * 997 + 13);
    const speed = 36 + rnd() * 80;
    const offset = rnd() * h;
    const trail = 16 + Math.floor(rnd() * 10);
    const head = (t * speed + offset) % (h + size * trail);
    for (let i = 0; i < trail; i++) {
      const y = head - i * size;
      if (y < -size || y > h) continue;
      const glyph = GLYPHS.charAt((c * 13 + i * 3 + Math.floor(t * (i === 0 ? 9 : 1.5))) % GLYPHS.length);
      const k = 1 - i / trail;
      ctx.fillStyle =
        i === 0
          ? "#f4fff8"
          : `rgba(${Math.round(90 + 80 * k)}, ${Math.round(220 + 35 * k)}, ${Math.round(130 + 40 * k)}, ${0.28 + k * 0.72})`;
      ctx.fillText(glyph, c * size, y);
    }
  }
}

function drawAurora(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, "#07060a");
  g.addColorStop(0.5, "#0d1412");
  g.addColorStop(1, "#120e0b");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  const rnd = mulberry32(3);
  for (let i = 0; i < 70; i++) {
    const x = rnd() * w;
    const y = rnd() * h * 0.5;
    const tw = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(t * 1.4 + i));
    ctx.fillStyle = `rgba(244,236,227,${0.18 * tw})`;
    ctx.fillRect(x, y, 1.4, 1.4);
  }
  const bands = [
    { y: 0.3, color: "rgba(88, 176, 138, 0.38)", amp: 0.055, ph: 0 },
    { y: 0.38, color: "rgba(227, 154, 82, 0.2)", amp: 0.04, ph: 1.3 },
    { y: 0.34, color: "rgba(186, 214, 196, 0.22)", amp: 0.07, ph: 2.1 },
  ];
  for (const b of bands) {
    const base = h * b.y;
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (let x = 0; x <= w; x += 8) {
      const y =
        base +
        Math.sin(x * 0.008 + t * 0.32 + b.ph) * h * b.amp +
        Math.sin(x * 0.021 - t * 0.45 + b.ph) * h * 0.018;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(w, h);
    ctx.closePath();
    const lg = ctx.createLinearGradient(0, base - h * 0.14, 0, base + h * 0.28);
    lg.addColorStop(0, "rgba(0,0,0,0)");
    lg.addColorStop(0.5, b.color);
    lg.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = lg;
    ctx.fill();
  }
}

function drawStars(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  ctx.fillStyle = "#07060a";
  ctx.fillRect(0, 0, w, h);
  const ng = ctx.createRadialGradient(w * 0.68, h * 0.28, 0, w * 0.68, h * 0.28, w * 0.75);
  ng.addColorStop(0, "rgba(227,154,82,0.16)");
  ng.addColorStop(0.45, "rgba(36,24,18,0.25)");
  ng.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = ng;
  ctx.fillRect(0, 0, w, h);
  const rnd = mulberry32(11);
  for (let i = 0; i < 130; i++) {
    const x = rnd() * w;
    const y = rnd() * h;
    const z = rnd();
    const s = z > 0.93 ? 2.1 : z > 0.72 ? 1.45 : 0.9;
    const tw = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(t * (0.7 + z) + i));
    ctx.fillStyle = z > 0.86 ? `rgba(227,154,82,${tw})` : `rgba(244,236,227,${0.2 + 0.75 * tw * z})`;
    ctx.beginPath();
    ctx.arc(x, y, s, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawEmbers(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, "#07060a");
  g.addColorStop(1, "#1c0e09");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  const glow = ctx.createRadialGradient(w * 0.5, h * 0.92, 0, w * 0.5, h * 0.92, h * 0.45);
  glow.addColorStop(0, "rgba(180,70,24,0.35)");
  glow.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, w, h);
  const rnd = mulberry32(21);
  for (let i = 0; i < 64; i++) {
    const x0 = rnd() * w;
    const speed = 18 + rnd() * 46;
    const phase = rnd();
    const size = 1.2 + rnd() * 2.4;
    const amber = 70 + Math.floor(rnd() * 90);
    const y = h + 20 - ((t * speed + phase * h) % (h + 50));
    const x = x0 + Math.sin(t * 0.7 + i) * 10;
    const life = Math.min(1, Math.max(0, y / h));
    ctx.beginPath();
    ctx.fillStyle = `rgba(227,${amber},42,${0.12 + (1 - life) * 0.75})`;
    ctx.arc(x, y, size * (0.6 + (1 - life)), 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawBokeh(ctx: CanvasRenderingContext2D, w: number, h: number, t: number, seed: number) {
  ctx.fillStyle = "#0c0a09";
  ctx.fillRect(0, 0, w, h);
  const vg = ctx.createRadialGradient(w * 0.45, h * 0.32, 0, w * 0.5, h * 0.4, w * 0.85);
  vg.addColorStop(0, "#2c1d14");
  vg.addColorStop(1, "#0c0a09");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, w, h);
  const rnd = mulberry32(seed);
  for (let i = 0; i < 26; i++) {
    const x = rnd() * w;
    const y = rnd() * h;
    const r = 14 + rnd() * 46;
    const drift = Math.sin(t * 0.28 + i) * 8;
    const amber = rnd() > 0.42;
    const cg = ctx.createRadialGradient(x + drift, y, 0, x + drift, y, r);
    cg.addColorStop(0, amber ? "rgba(227,154,82,0.3)" : "rgba(244,236,227,0.12)");
    cg.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(x + drift, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawNiholFront(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  const sway = Math.sin(t * 0.6) * w * 0.012;
  const x0 = w * 1.04;
  const y0 = h * 0.96;
  const x1 = w * 0.84;
  const y1 = h * 0.62;
  const x2 = w * 0.6 + sway;
  const y2 = h * 0.34;
  const x3 = w * 0.22 + sway * 1.3;
  const y3 = h * 0.06;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.bezierCurveTo(x1, y1, x2, y2, x3, y3);
  ctx.strokeStyle = "#2a2418";
  ctx.lineWidth = Math.max(2.5, w * 0.018);
  ctx.stroke();
  ctx.strokeStyle = "#6a5b45";
  ctx.lineWidth = Math.max(1, w * 0.004);
  ctx.stroke();

  for (let i = 0; i < 18; i++) {
    const t0 = 0.06 + (i / 18) * 0.9;
    const x = bez(x0, x1, x2, x3, t0);
    const y = bez(y0, y1, y2, y3, t0);
    const side = i % 2 === 0 ? 1 : -1;
    const ax0 = bez(x0, x1, x2, x3, Math.max(0, t0 - 0.02));
    const ax1 = bez(x0, x1, x2, x3, Math.min(1, t0 + 0.02));
    const ay0 = bez(y0, y1, y2, y3, Math.max(0, t0 - 0.02));
    const ay1 = bez(y0, y1, y2, y3, Math.min(1, t0 + 0.02));
    const ang = Math.atan2(ay1 - ay0, ax1 - ax0) + side * (0.85 + (i % 3) * 0.18);
    const len = w * (0.055 + (1 - t0) * 0.07);
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(ang);
    ctx.beginPath();
    ctx.ellipse(len * 0.46, 0, len * 0.48, len * 0.16, 0, 0, Math.PI * 2);
    const lg = ctx.createLinearGradient(0, 0, len, 0);
    const dark = i % 3 === 0;
    lg.addColorStop(0, dark ? "#3c4426" : "#556332");
    lg.addColorStop(0.55, dark ? "#8d9758" : "#c3c98a");
    lg.addColorStop(1, "#e4e2c2");
    ctx.fillStyle = lg;
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(len * 0.12, 0);
    ctx.lineTo(len * 0.86, 0);
    ctx.strokeStyle = "rgba(36,42,18,0.4)";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();
  }
}

function drawOrchidFront(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  const sway = Math.sin(t * 0.5) * w * 0.01;
  const x0 = w * 0.16;
  const y0 = h * 1.02;
  const x1 = w * 0.1;
  const y1 = h * 0.66;
  const x2 = w * 0.32 + sway;
  const y2 = h * 0.38;
  const x3 = w * 0.46 + sway;
  const y3 = h * 0.2;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.bezierCurveTo(x1, y1, x2, y2, x3, y3);
  ctx.strokeStyle = "#1b3a28";
  ctx.lineWidth = Math.max(2, w * 0.013);
  ctx.stroke();

  for (const side of [-1, 1]) {
    const t0 = 0.42;
    ctx.save();
    ctx.translate(bez(x0, x1, x2, x3, t0), bez(y0, y1, y2, y3, t0));
    ctx.rotate(side * 1.15);
    ctx.beginPath();
    ctx.ellipse(w * 0.07, 0, w * 0.09, w * 0.016, 0, 0, Math.PI * 2);
    ctx.fillStyle = side < 0 ? "#245036" : "#326848";
    ctx.fill();
    ctx.restore();
  }

  ctx.save();
  ctx.translate(x3, y3);
  for (let i = 0; i < 5; i++) {
    ctx.save();
    ctx.rotate((i / 5) * Math.PI * 2 - Math.PI / 2);
    ctx.beginPath();
    ctx.ellipse(w * 0.055, 0, w * 0.072, w * 0.03, 0, 0, Math.PI * 2);
    ctx.fillStyle = i % 2 === 0 ? "#fbf7f1" : "#f3ece2";
    ctx.fill();
    ctx.restore();
  }
  ctx.beginPath();
  ctx.ellipse(w * 0.01, w * 0.028, w * 0.042, w * 0.026, 0.5, 0, Math.PI * 2);
  ctx.fillStyle = "#f4e4c8";
  ctx.fill();
  ctx.beginPath();
  ctx.arc(0, 0, w * 0.016, 0, Math.PI * 2);
  ctx.fillStyle = "#e39a52";
  ctx.fill();
  ctx.restore();
}

function drawQumBack(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, "#07060a");
  g.addColorStop(0.38, "#1a120e");
  g.addColorStop(0.58, "#6a3b22");
  g.addColorStop(0.66, "#d08848");
  g.addColorStop(1, "#24140e");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  const rnd = mulberry32(5);
  for (let i = 0; i < 48; i++) {
    const x = rnd() * w;
    const y = rnd() * h * 0.42;
    const tw = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(t * 1.2 + i));
    ctx.fillStyle = `rgba(244,236,227,${0.55 * tw})`;
    ctx.fillRect(x, y, 1.3, 1.3);
  }
  const mx = w * 0.73;
  const my = h * 0.22;
  const mr = Math.min(w, h) * 0.105;
  const mg = ctx.createRadialGradient(mx - mr * 0.2, my - mr * 0.2, mr * 0.2, mx, my, mr * 2.6);
  mg.addColorStop(0, "rgba(255,244,230,0.95)");
  mg.addColorStop(0.28, "rgba(243,214,170,0.45)");
  mg.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = mg;
  ctx.beginPath();
  ctx.arc(mx, my, mr * 2.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(mx, my, mr, 0, Math.PI * 2);
  ctx.fillStyle = "#f7f0e6";
  ctx.fill();
  ctx.beginPath();
  ctx.arc(mx - mr * 0.28, my - mr * 0.22, mr * 0.22, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(210,190,160,0.28)";
  ctx.fill();
}

function duneY(x: number, w: number, h: number) {
  const nx = x / w - 0.48;
  const peak = Math.exp(-(nx / 0.58) * (nx / 0.58));
  return h * 0.8 - peak * h * 0.58 + Math.sin(x * 0.035) * h * 0.008;
}

function drawQumFront(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.beginPath();
  ctx.moveTo(0, h);
  for (let x = 0; x <= w; x += 3) ctx.lineTo(x, duneY(x, w, h));
  ctx.lineTo(w, h);
  ctx.closePath();
  const g = ctx.createLinearGradient(0, h * 0.18, 0, h);
  g.addColorStop(0, "#5a4030");
  g.addColorStop(0.08, "#2a1c14");
  g.addColorStop(1, "#0c0908");
  ctx.fillStyle = g;
  ctx.fill();
  const rnd = mulberry32(44);
  ctx.save();
  ctx.clip();
  for (let i = 0; i < 180; i++) {
    ctx.fillStyle = rnd() > 0.5 ? "rgba(255,220,180,0.05)" : "rgba(0,0,0,0.18)";
    ctx.fillRect(rnd() * w, h * 0.2 + rnd() * h * 0.8, 1.5, 1.5);
  }
  ctx.restore();
  ctx.beginPath();
  for (let x = 0; x <= w; x += 3) {
    const y = duneY(x, w, h);
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = "rgba(227,170,110,0.45)";
  ctx.lineWidth = 1.5;
  ctx.stroke();
}

function drawRavoqBack(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  ctx.fillStyle = "#140e0b";
  ctx.fillRect(0, 0, w, h);
  const g = ctx.createRadialGradient(w / 2, h * 0.48, 0, w / 2, h * 0.48, w * 0.72);
  g.addColorStop(0, "#f2c79a");
  g.addColorStop(0.22, "#c47a3a");
  g.addColorStop(0.5, "#5a3018");
  g.addColorStop(1, "#140e0b");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  const rnd = mulberry32(8);
  for (let i = 0; i < 28; i++) {
    const x = w * 0.28 + rnd() * w * 0.44;
    const y = h * 0.18 + rnd() * h * 0.5;
    const tw = 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(t * 0.8 + i));
    ctx.fillStyle = `rgba(255,236,210,${0.28 * tw})`;
    ctx.beginPath();
    ctx.arc(x, y, 1.2, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawRavoqFront(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.fillStyle = "#1b140f";
  ctx.fillRect(0, 0, w, h);
  const rnd = mulberry32(2);
  for (let i = 0; i < 360; i++) {
    ctx.fillStyle = rnd() > 0.55 ? "rgba(255,220,180,0.045)" : "rgba(0,0,0,0.16)";
    ctx.fillRect(rnd() * w, rnd() * h, 2, 2);
  }
  const cx = w / 2;
  const cy = h * 0.5;
  const rx = w * 0.3;
  const ry = h * 0.3;
  ctx.globalCompositeOperation = "destination-out";
  ctx.beginPath();
  ctx.moveTo(cx - rx, h + 2);
  ctx.lineTo(cx - rx, cy);
  ctx.ellipse(cx, cy, rx, ry, 0, Math.PI, 0);
  ctx.lineTo(cx + rx, h + 2);
  ctx.closePath();
  ctx.fill();
  ctx.globalCompositeOperation = "source-over";
  ctx.beginPath();
  ctx.moveTo(cx - rx, h);
  ctx.lineTo(cx - rx, cy);
  ctx.ellipse(cx, cy, rx, ry, 0, Math.PI, 0);
  ctx.strokeStyle = "rgba(227,154,82,0.5)";
  ctx.lineWidth = Math.max(2, w * 0.012);
  ctx.stroke();
}

function drawSeaBack(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, "#070a10");
  g.addColorStop(0.4, "#152433");
  g.addColorStop(0.5, "#e0a36a");
  g.addColorStop(0.54, "#1a303c");
  g.addColorStop(1, "#07090c");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "rgba(244,220,190,0.12)";
  ctx.fillRect(w * 0.46, h * 0.52, w * 0.06, h * 0.28);
  ctx.strokeStyle = "rgba(244,236,227,0.09)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 9; i++) {
    ctx.beginPath();
    const yb = h * (0.58 + i * 0.045);
    for (let x = 0; x <= w; x += 8) {
      const y = yb + Math.sin(x * 0.02 + t * 0.55 + i) * 3;
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
}

function drawSeaFront(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.beginPath();
  ctx.moveTo(w * 0.58, h + 4);
  ctx.lineTo(w * 0.66, h * 0.62);
  ctx.lineTo(w * 0.74, h * 0.28);
  ctx.lineTo(w * 0.8, h * 0.15);
  ctx.lineTo(w * 0.88, h * 0.22);
  ctx.lineTo(w * 0.93, h * 0.4);
  ctx.lineTo(w * 1.02, h * 0.34);
  ctx.lineTo(w * 1.02, h + 4);
  ctx.closePath();
  const g = ctx.createLinearGradient(w * 0.7, h * 0.15, w * 0.85, h);
  g.addColorStop(0, "#2a241c");
  g.addColorStop(0.2, "#121418");
  g.addColorStop(1, "#07080a");
  ctx.fillStyle = g;
  ctx.fill();
  ctx.strokeStyle = "rgba(227,154,82,0.28)";
  ctx.lineWidth = 1.25;
  ctx.stroke();
}

function drawRainBack(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  ctx.fillStyle = "#08090c";
  ctx.fillRect(0, 0, w, h);
  const rnd = mulberry32(15);
  for (let i = 0; i < 20; i++) {
    const x = rnd() * w;
    const y = rnd() * h;
    const r = 10 + rnd() * 34;
    const cg = ctx.createRadialGradient(x, y, 0, x, y, r);
    cg.addColorStop(0, rnd() > 0.5 ? "rgba(227,154,82,0.34)" : "rgba(210,218,226,0.16)");
    cg.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.strokeStyle = "rgba(226,232,240,0.2)";
  ctx.lineWidth = 1;
  const rnd2 = mulberry32(16);
  for (let i = 0; i < 70; i++) {
    const x = rnd2() * w;
    const len = 12 + rnd2() * 16;
    const speed = 90 + rnd2() * 110;
    const y = ((rnd2() * h + t * speed) % (h + 30)) - 20;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x - 1.5, y + len);
    ctx.stroke();
  }
}

function drawRainFront(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const x = w * 0.8;
  ctx.strokeStyle = "#07080c";
  ctx.fillStyle = "#07080c";
  ctx.lineCap = "round";
  ctx.lineWidth = Math.max(5, w * 0.022);
  ctx.beginPath();
  ctx.moveTo(x, h + 8);
  ctx.lineTo(x, h * 0.12);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x, h * 0.15);
  ctx.quadraticCurveTo(x + w * 0.02, h * 0.1, x + w * 0.11, h * 0.16);
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(x + w * 0.1, h * 0.175, w * 0.05, w * 0.03, 0.1, 0, Math.PI * 2);
  ctx.fill();
}

function ribbon(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  t: number,
  y0: number,
  amp: number,
  color: string,
  width: number,
  phase: number,
) {
  ctx.beginPath();
  for (let x = -10; x <= w + 10; x += 6) {
    const y =
      h * y0 +
      Math.sin(x * 0.0075 + t * 0.35 + phase) * h * amp +
      Math.sin(x * 0.016 - t * 0.22 + phase) * h * amp * 0.35;
    if (x === -10) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.stroke();
}

function drawSilkBack(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  ctx.fillStyle = "#100e0c";
  ctx.fillRect(0, 0, w, h);
  ribbon(ctx, w, h, t, 0.58, 0.07, "rgba(227,154,82,0.16)", h * 0.11, 0);
  ribbon(ctx, w, h, t, 0.72, 0.045, "rgba(244,236,227,0.06)", h * 0.07, 1.7);
  ribbon(ctx, w, h, t, 0.42, 0.06, "rgba(90,48,28,0.4)", h * 0.09, 2.4);
}

function drawSilkFront(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  ribbon(ctx, w, h, t, 0.25, 0.045, "rgba(196,112,52,0.94)", Math.max(16, h * 0.042), 0.5);
  ribbon(ctx, w, h, t, 0.25, 0.045, "rgba(255,236,214,0.38)", Math.max(4, h * 0.01), 0.5);
}

function drawBlackHoleThumb(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.fillStyle = "#07060a";
  ctx.fillRect(0, 0, w, h);
  const cx = w / 2;
  const cy = h * 0.46;
  const r = w * 0.32;
  const g = ctx.createRadialGradient(cx, cy, r * 0.15, cx, cy, r * 1.7);
  g.addColorStop(0, "#000");
  g.addColorStop(0.42, "#000");
  g.addColorStop(0.52, "#f0c08a");
  g.addColorStop(0.66, "#8a3a12");
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 1.7, 0, Math.PI * 2);
  ctx.fill();
}

export function drawScene(id: SceneId, layer: Layer, ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  if (layer === "front") {
    if (id === "nihol") drawNiholFront(ctx, w, h, t);
    else if (id === "orxideya") drawOrchidFront(ctx, w, h, t);
    else if (id === "qum") drawQumFront(ctx, w, h);
    else if (id === "ravoq") drawRavoqFront(ctx, w, h);
    else if (id === "dengiz") drawSeaFront(ctx, w, h);
    else if (id === "yomgir") drawRainFront(ctx, w, h);
    else if (id === "ipak") drawSilkFront(ctx, w, h, t);
    return;
  }
  if (id === "matritsa") drawMatrix(ctx, w, h, t);
  else if (id === "aurora") drawAurora(ctx, w, h, t);
  else if (id === "yulduz") drawStars(ctx, w, h, t);
  else if (id === "chog") drawEmbers(ctx, w, h, t);
  else if (id === "nihol" || id === "orxideya") drawBokeh(ctx, w, h, t, id === "nihol" ? 31 : 37);
  else if (id === "qum") drawQumBack(ctx, w, h, t);
  else if (id === "ravoq") drawRavoqBack(ctx, w, h, t);
  else if (id === "dengiz") drawSeaBack(ctx, w, h, t);
  else if (id === "yomgir") drawRainBack(ctx, w, h, t);
  else drawSilkBack(ctx, w, h, t);
}

export function drawPresetThumb(id: WallpaperId, ctx: CanvasRenderingContext2D, w: number, h: number) {
  if (id === "tuynuk") {
    drawBlackHoleThumb(ctx, w, h);
    return;
  }
  if (id === "user-image" || id === "user-video" || id === "user-html") return;
  drawScene(id, "back", ctx, w, h, 1.6);
  drawScene(id, "front", ctx, w, h, 1.6);
}
