import { useEffect } from "react";
import { ClockFace } from "@/components/clock-face";
import { EditorSheet } from "@/components/editor-sheet";
import { BackLayer, FrontLayer } from "@/components/wallpaper-stage";
import { idbGet } from "@/lib/media-db";
import { useQatlam } from "@/lib/store";

function useHydrateMedia() {
  useEffect(() => {
    let gone = false;
    const created: string[] = [];
    void (async () => {
      try {
        await useQatlam.persist.rehydrate();
      } catch {
        /* preview without storage */
      }
      let image: Blob | string | undefined;
      let video: Blob | string | undefined;
      let html: Blob | string | undefined;
      try {
        [image, video, html] = await Promise.all([idbGet("image"), idbGet("video"), idbGet("html")]);
      } catch {
        /* private mode */
      }
      if (gone) return;
      const patch: { imageUrl?: string; videoUrl?: string; html?: string; mediaReady: boolean } = {
        mediaReady: true,
      };
      if (image instanceof Blob) {
        const url = URL.createObjectURL(image);
        created.push(url);
        patch.imageUrl = url;
      }
      if (video instanceof Blob) {
        const url = URL.createObjectURL(video);
        created.push(url);
        patch.videoUrl = url;
      }
      if (typeof html === "string") patch.html = html;
      useQatlam.setState(patch);
    })();
    return () => {
      gone = true;
      for (const url of created) URL.revokeObjectURL(url);
    };
  }, []);
}

export function LockScreen() {
  useHydrateMedia();
  const editing = useQatlam((s) => s.editing);
  const setEditing = useQatlam((s) => s.setEditing);
  const wallpaper = useQatlam((s) => s.wallpaper);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setEditing(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setEditing]);

  return (
    <main className="fixed inset-0 overflow-hidden bg-void text-ink">
      <h1 className="sr-only">Qatlam — qulf ekrani</h1>
      <div className="absolute inset-0 z-0">
        <BackLayer id={wallpaper} />
      </div>
      <div className="vignette pointer-events-none absolute inset-0 z-10" aria-hidden />
      <ClockFace />
      <div className="pointer-events-none absolute inset-0 z-30">
        <FrontLayer id={wallpaper} />
      </div>
      {editing ? null : (
        <button
          type="button"
          onClick={() => setEditing(true)}
          className="fixed bottom-[max(1.25rem,env(safe-area-inset-bottom))] left-1/2 z-40 min-h-11 -translate-x-1/2 rounded-full border border-line bg-surface/75 px-5 text-sm text-ink backdrop-blur-md"
        >
          Sozlash
        </button>
      )}
      <EditorSheet />
    </main>
  );
}
