import { useEffect, useRef } from "react";
import { BlackHole } from "@/components/live/black-hole";
import { SceneCanvas } from "@/components/live/scene-canvas";
import { hasSceneFront, isScene, type WallpaperId } from "@/lib/presets";
import { useQatlam } from "@/lib/store";

let leadVideo: HTMLVideoElement | null = null;

function UserImage({ layer }: { layer: "back" | "front" }) {
  const url = useQatlam((s) => s.imageUrl);
  const alpha = useQatlam((s) => s.userImageHasAlpha);
  const depth = useQatlam((s) => s.depth);
  const maskX = useQatlam((s) => s.maskX);
  const maskY = useQatlam((s) => s.maskY);
  const maskW = useQatlam((s) => s.maskW);
  const maskH = useQatlam((s) => s.maskH);
  const feather = useQatlam((s) => s.feather);
  if (!url) return null;
  if (layer === "front" && !depth) return null;
  if (layer === "back" && depth && alpha) {
    return (
      <img
        src={url}
        alt=""
        className="pointer-events-none absolute inset-0 h-full w-full scale-110 object-cover opacity-80 blur-2xl"
      />
    );
  }
  if (layer === "front" && alpha) {
    return <img src={url} alt="" className="pointer-events-none absolute inset-0 h-full w-full object-cover" />;
  }
  if (layer === "front") {
    const inner = Math.max(8, 62 - feather);
    const outer = Math.min(98, 70 + feather * 0.35);
    const image = `radial-gradient(ellipse ${maskW}% ${maskH}% at ${maskX}% ${maskY}%, #000 ${inner}%, transparent ${outer}%)`;
    return (
      <img
        src={url}
        alt=""
        className="pointer-events-none absolute inset-0 h-full w-full object-cover"
        style={{ WebkitMaskImage: image, maskImage: image }}
      />
    );
  }
  return <img src={url} alt="" className="pointer-events-none absolute inset-0 h-full w-full object-cover" />;
}

function UserVideo({ layer }: { layer: "back" | "front" }) {
  const url = useQatlam((s) => s.videoUrl);
  const depth = useQatlam((s) => s.depth);
  const maskX = useQatlam((s) => s.maskX);
  const maskY = useQatlam((s) => s.maskY);
  const maskW = useQatlam((s) => s.maskW);
  const maskH = useQatlam((s) => s.maskH);
  const feather = useQatlam((s) => s.feather);
  const ref = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    if (layer === "back") leadVideo = video;
    const play = () => void video.play().catch(() => {});
    play();
    const sync = () => {
      if (layer === "front" && leadVideo && Math.abs(video.currentTime - leadVideo.currentTime) > 0.25) {
        video.currentTime = leadVideo.currentTime;
      }
    };
    video.addEventListener("timeupdate", sync);
    window.addEventListener("pointerdown", play);
    return () => {
      video.removeEventListener("timeupdate", sync);
      window.removeEventListener("pointerdown", play);
      if (leadVideo === video) leadVideo = null;
    };
  }, [url, layer]);

  if (!url || (layer === "front" && !depth)) return null;
  const inner = Math.max(8, 62 - feather);
  const outer = Math.min(98, 70 + feather * 0.35);
  const image = `radial-gradient(ellipse ${maskW}% ${maskH}% at ${maskX}% ${maskY}%, #000 ${inner}%, transparent ${outer}%)`;
  return (
    <video
      ref={ref}
      src={url}
      muted
      loop
      autoPlay
      playsInline
      className="pointer-events-none absolute inset-0 h-full w-full object-cover"
      style={layer === "front" ? { WebkitMaskImage: image, maskImage: image } : undefined}
    />
  );
}

function UserHtml() {
  const html = useQatlam((s) => s.html);
  if (!html) {
    return (
      <div className="absolute inset-0 flex items-center justify-center px-8 text-center text-mute">
        HTML fayl yoki kod qo‘ying — masalan, qora tuynuk sahifasi.
      </div>
    );
  }
  return (
    <iframe
      title="HTML fon"
      sandbox="allow-scripts"
      srcDoc={html}
      className="absolute inset-0 h-full w-full border-0 bg-void"
    />
  );
}

export function BackLayer({ id }: { id: WallpaperId }) {
  if (id === "tuynuk") return <BlackHole />;
  if (id === "user-html") return <UserHtml />;
  if (id === "user-image") return <UserImage layer="back" />;
  if (id === "user-video") return <UserVideo layer="back" />;
  if (isScene(id)) return <SceneCanvas id={id} layer="back" />;
  return null;
}

export function FrontLayer({ id }: { id: WallpaperId }) {
  const depth = useQatlam((s) => s.depth);
  if (!depth) return null;
  if (id === "user-image") return <UserImage layer="front" />;
  if (id === "user-video") return <UserVideo layer="front" />;
  if (hasSceneFront(id) && isScene(id)) return <SceneCanvas id={id} layer="front" />;
  return null;
}
