import { useRef, useState } from "react";
import { Code, ImageIcon, Video } from "lucide-react";
import { WallpaperThumb } from "@/components/live/scene-canvas";
import { cn } from "@/lib/cn";
import { colorToHex, FONTS, WALLPAPERS, hasSceneFront, type WallpaperId } from "@/lib/presets";
import { useQatlam } from "@/lib/store";

type Tab = "fon" | "soat" | "qatlam";

function Toggle({
  label,
  on,
  onChange,
  disabled,
}: {
  label: string;
  on: boolean;
  onChange: (value: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      disabled={disabled}
      onClick={() => onChange(!on)}
      className="flex min-h-11 w-full items-center justify-between gap-4 py-1 text-left text-sm text-ink disabled:opacity-40"
    >
      <span>{label}</span>
      <span className={cn("relative h-7 w-12 shrink-0 rounded-full", on && !disabled ? "bg-amber" : "bg-line")}>
        <span
          className={cn(
            "absolute top-0.5 left-0.5 size-6 rounded-full bg-ink transition-transform duration-200",
            on && !disabled && "translate-x-5",
          )}
        />
      </span>
    </button>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  display,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  display: string;
  onChange: (value: number) => void;
}) {
  return (
    <label className="flex flex-col gap-1 text-sm text-ink">
      <span className="flex items-center justify-between text-mute">
        <span>{label}</span>
        <span className="tabular-nums text-ink">{display}</span>
      </span>
      <input
        className="range"
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    </label>
  );
}

function PresetButton({ id, name }: { id: WallpaperId; name: string }) {
  const current = useQatlam((s) => s.wallpaper);
  const select = useQatlam((s) => s.selectWallpaper);
  const selected = current === id;
  return (
    <button
      type="button"
      aria-pressed={selected}
      onClick={() => select(id)}
      className="flex w-16 shrink-0 flex-col gap-1.5"
    >
      <span
        className={cn(
          "block h-24 w-16 overflow-hidden rounded-2xl border",
          selected ? "border-amber" : "border-line",
        )}
      >
        <WallpaperThumb id={id} />
      </span>
      <span className={cn("truncate text-center text-xs", selected ? "text-ink" : "text-mute")}>{name}</span>
    </button>
  );
}

export function EditorSheet() {
  const editing = useQatlam((s) => s.editing);
  const setEditing = useQatlam((s) => s.setEditing);
  const [tab, setTab] = useState<Tab>("fon");
  const imageRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLInputElement>(null);
  const htmlRef = useRef<HTMLInputElement>(null);
  const [draft, setDraft] = useState("");

  const wallpaper = useQatlam((s) => s.wallpaper);
  const font = useQatlam((s) => s.font);
  const weight = useQatlam((s) => s.weight);
  const scale = useQatlam((s) => s.scale);
  const color = useQatlam((s) => s.color);
  const shadow = useQatlam((s) => s.shadow);
  const seconds = useQatlam((s) => s.seconds);
  const showDate = useQatlam((s) => s.showDate);
  const showClock = useQatlam((s) => s.showClock);
  const clockY = useQatlam((s) => s.clockY);
  const depth = useQatlam((s) => s.depth);
  const maskX = useQatlam((s) => s.maskX);
  const maskY = useQatlam((s) => s.maskY);
  const maskW = useQatlam((s) => s.maskW);
  const maskH = useQatlam((s) => s.maskH);
  const feather = useQatlam((s) => s.feather);
  const alpha = useQatlam((s) => s.userImageHasAlpha);
  const imageUrl = useQatlam((s) => s.imageUrl);
  const videoUrl = useQatlam((s) => s.videoUrl);
  const html = useQatlam((s) => s.html);
  const notice = useQatlam((s) => s.notice);
  const setFont = useQatlam((s) => s.setFont);
  const setWeight = useQatlam((s) => s.setWeight);
  const setScale = useQatlam((s) => s.setScale);
  const setColor = useQatlam((s) => s.setColor);
  const setShadow = useQatlam((s) => s.setShadow);
  const setSeconds = useQatlam((s) => s.setSeconds);
  const setShowDate = useQatlam((s) => s.setShowDate);
  const setShowClock = useQatlam((s) => s.setShowClock);
  const setClockY = useQatlam((s) => s.setClockY);
  const setDepth = useQatlam((s) => s.setDepth);
  const setMask = useQatlam((s) => s.setMask);
  const useImageFile = useQatlam((s) => s.useImageFile);
  const useVideoFile = useQatlam((s) => s.useVideoFile);
  const useHtmlFile = useQatlam((s) => s.useHtmlFile);
  const useHtmlText = useQatlam((s) => s.useHtmlText);
  const useSampleHtml = useQatlam((s) => s.useSampleHtml);
  const clearUserMedia = useQatlam((s) => s.clearUserMedia);

  const live = WALLPAPERS.filter((item) => item.group === "live");
  const studio = WALLPAPERS.filter((item) => item.group === "studio");
  const photo = wallpaper === "user-image" || wallpaper === "user-video";
  const depthOk = hasSceneFront(wallpaper) || photo;

  return (
    <section
      className={cn(
        "sheet fixed inset-x-0 bottom-0 z-40 flex flex-col overflow-hidden rounded-t-3xl border border-line backdrop-blur-xl",
        editing ? "translate-y-0" : "pointer-events-none translate-y-full",
      )}
      aria-hidden={!editing}
      inert={!editing}
    >
      <div className="sticky top-0 z-10 border-b border-line bg-surface/90 px-5 pt-3 pb-3 backdrop-blur-md">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-medium text-balance text-ink">Qatlam</h1>
            <p className="text-xs text-mute">Soatni rasm orqasiga qo‘ying</p>
          </div>
          <button
            type="button"
            onClick={() => setEditing(false)}
            className="rounded-full bg-amber px-4 py-2 text-sm font-medium text-void"
          >
            Tayyor
          </button>
        </div>
        <div className="grid grid-cols-3 gap-1 rounded-full bg-void p-1" role="tablist">
          {(
            [
              ["fon", "Fon"],
              ["soat", "Soat"],
              ["qatlam", "Qatlam"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              onClick={() => setTab(id)}
              className={cn(
                "min-h-11 rounded-full text-sm",
                tab === id ? "bg-amber text-void" : "text-mute",
              )}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="scroller flex flex-col gap-5 overflow-y-auto px-5 pt-4 pb-8">
        {notice ? <p className="text-sm text-amber">{notice}</p> : null}

        {tab === "fon" ? (
          <>
            <div className="flex flex-col gap-2">
              <h2 className="text-xs tracking-widest text-mute uppercase">Jonli</h2>
              <div className="scroller flex gap-3 overflow-x-auto pb-1">
                {live.map((item) => (
                  <PresetButton key={item.id} id={item.id} name={item.name} />
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <h2 className="text-xs tracking-widest text-mute uppercase">Studiya</h2>
              <div className="scroller flex gap-3 overflow-x-auto pb-1">
                {studio.map((item) => (
                  <PresetButton key={item.id} id={item.id} name={item.name} />
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-3">
              <h2 className="text-xs tracking-widest text-mute uppercase">O‘zingizniki</h2>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => imageRef.current?.click()}
                  className="flex min-h-16 flex-col items-center justify-center gap-1 rounded-2xl border border-line text-xs text-ink"
                >
                  <ImageIcon className="size-4" aria-hidden />
                  Rasm
                </button>
                <button
                  type="button"
                  onClick={() => videoRef.current?.click()}
                  className="flex min-h-16 flex-col items-center justify-center gap-1 rounded-2xl border border-line text-xs text-ink"
                >
                  <Video className="size-4" aria-hidden />
                  Video
                </button>
                <button
                  type="button"
                  onClick={() => htmlRef.current?.click()}
                  className="flex min-h-16 flex-col items-center justify-center gap-1 rounded-2xl border border-line text-xs text-ink"
                >
                  <Code className="size-4" aria-hidden />
                  HTML
                </button>
              </div>
              <input
                ref={imageRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  event.target.value = "";
                  if (file) void useImageFile(file);
                }}
              />
              <input
                ref={videoRef}
                type="file"
                accept="video/*"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  event.target.value = "";
                  if (file) void useVideoFile(file);
                }}
              />
              <input
                ref={htmlRef}
                type="file"
                accept=".html,text/html"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  event.target.value = "";
                  if (file) void useHtmlFile(file);
                }}
              />
              {imageUrl ? (
                <button type="button" className="text-left text-sm text-mute" onClick={() => void clearUserMedia("image")}>
                  Rasmni olib tashlash
                </button>
              ) : null}
              {videoUrl ? (
                <button type="button" className="text-left text-sm text-mute" onClick={() => void clearUserMedia("video")}>
                  Videoni olib tashlash
                </button>
              ) : null}
              <label className="flex flex-col gap-2 text-sm text-ink">
                HTML kod
                <textarea
                  value={draft}
                  onChange={(event) => setDraft(event.target.value)}
                  rows={4}
                  placeholder="<html>… matritsa yoki qora tuynuk sahifasi"
                  className="resize-none rounded-2xl border border-line bg-void px-3 py-3 text-sm text-ink outline-none placeholder:text-mute"
                />
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => void useHtmlText(draft)}
                  className="min-h-11 flex-1 rounded-full border border-line text-sm text-ink"
                >
                  Kodni qo‘yish
                </button>
                <button
                  type="button"
                  onClick={() => void useSampleHtml()}
                  className="min-h-11 flex-1 rounded-full border border-amber text-sm text-amber"
                >
                  Namuna: tuynuk
                </button>
              </div>
              {html ? (
                <button type="button" className="text-left text-sm text-mute" onClick={() => void clearUserMedia("html")}>
                  HTML fonni olib tashlash
                </button>
              ) : null}
              <p className="text-xs leading-relaxed text-pretty text-mute">
                Telefon tizim fonini sayt almashtira olmaydi. Ilovani bosh ekranga qo‘shsangiz, ochilganda shu qulf
                ekrani turadi.
              </p>
            </div>
          </>
        ) : null}

        {tab === "soat" ? (
          <div className="flex flex-col gap-4">
            <div className="scroller flex gap-2 overflow-x-auto pb-1">
              {FONTS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={font === item.id}
                  onClick={() => setFont(item.id)}
                  className={cn(
                    "min-h-11 shrink-0 rounded-full border px-4 text-sm",
                    font === item.id ? "border-amber bg-amber text-void" : "border-line text-ink",
                  )}
                  style={{ fontFamily: item.family }}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  [200, "Yupqa"],
                  [400, "Oddiy"],
                  [600, "Qalin"],
                ] as const
              ).map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  aria-pressed={weight === value}
                  onClick={() => setWeight(value)}
                  className={cn(
                    "min-h-11 rounded-full border text-sm",
                    weight === value ? "border-amber bg-amber text-void" : "border-line text-ink",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
            <Slider
              label="O‘lcham"
              min={70}
              max={150}
              step={1}
              value={Math.round(scale * 100)}
              display={`${Math.round(scale * 100)}%`}
              onChange={(value) => setScale(value / 100)}
            />
            <Slider
              label="Joyi"
              min={6}
              max={34}
              step={1}
              value={Math.round(clockY)}
              display={`${Math.round(clockY)}`}
              onChange={setClockY}
            />
            <div className="flex items-center gap-3">
              {(
                [
                  ["ink", "Oq", "var(--color-ink)"],
                  ["silver", "Kumush", "var(--color-silver)"],
                  ["amber", "Amber", "var(--color-amber)"],
                ] as const
              ).map(([id, label, value]) => (
                <button
                  key={id}
                  type="button"
                  aria-label={label}
                  aria-pressed={color === id}
                  onClick={() => setColor(id)}
                  className={cn("size-11 rounded-full border-2", color === id ? "border-amber" : "border-line")}
                  style={{ background: value }}
                />
              ))}
              <label className="flex items-center gap-2 text-sm text-mute">
                O‘z rangi
                <input
                  type="color"
                  value={colorToHex(color)}
                  aria-label="O‘z rangi"
                  onChange={(event) => setColor(event.target.value)}
                  className="size-11 cursor-pointer rounded-full border border-line bg-void"
                />
              </label>
            </div>
            <Toggle label="Sana" on={showDate} onChange={setShowDate} />
            <Toggle label="Soniya" on={seconds} onChange={setSeconds} />
            <Toggle label="Soya" on={shadow} onChange={setShadow} />
            <Toggle label="Soatni ko‘rsatish" on={showClock} onChange={setShowClock} />
          </div>
        ) : null}

        {tab === "qatlam" ? (
          <div className="flex flex-col gap-3">
            <Toggle label="Soat rasm orqasida" on={depth} onChange={setDepth} disabled={!depthOk} />
            {hasSceneFront(wallpaper) ? (
              <p className="text-sm leading-relaxed text-pretty text-mute">
                Old qatlam — qum, ravoq, nihol — soat raqamlarini yopadi. Soatni ushlab sudrang yoki Joyi slayderini
                siljiting.
              </p>
            ) : null}
            {photo && !(wallpaper === "user-image" && alpha) ? (
              <>
                <p className="text-sm leading-relaxed text-pretty text-mute">
                  Niqobni odam yoki buyum ustiga qo‘ying. Shu joy soatning oldiga chiqadi — iPhone dagi kabi.
                </p>
                <Slider label="Markaz X" min={10} max={90} step={1} value={maskX} display={`${Math.round(maskX)}`} onChange={(value) => setMask({ maskX: value })} />
                <Slider label="Markaz Y" min={10} max={90} step={1} value={maskY} display={`${Math.round(maskY)}`} onChange={(value) => setMask({ maskY: value })} />
                <Slider label="Eni" min={30} max={120} step={1} value={maskW} display={`${Math.round(maskW)}`} onChange={(value) => setMask({ maskW: value })} />
                <Slider label="Bo‘yi" min={20} max={100} step={1} value={maskH} display={`${Math.round(maskH)}`} onChange={(value) => setMask({ maskH: value })} />
                <Slider label="Pat" min={0} max={40} step={1} value={feather} display={`${Math.round(feather)}`} onChange={(value) => setMask({ feather: value })} />
              </>
            ) : null}
            {wallpaper === "user-image" && alpha ? (
              <p className="text-sm leading-relaxed text-pretty text-mute">
                Shaffof PNG aniqlandi. Rasmning o‘zi soatni yopadi, bo‘sh joydan soat ko‘rinadi.
              </p>
            ) : null}
            {!depthOk ? (
              <p className="text-sm leading-relaxed text-pretty text-mute">
                Matritsa va qora tuynukda old qatlam yo‘q. Qumlar, ravoq yoki o‘z rasmingizda soat orqaga tushadi. HTML
                sahifa o‘z ekranini ko‘rsatadi — soatni alohida yoqishingiz mumkin.
              </p>
            ) : null}
          </div>
        ) : null}
      </div>
    </section>
  );
}
