import { createFileRoute } from "@tanstack/react-router";
import { LockScreen } from "@/components/lock-screen";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <LockScreen />;
}
