export type WallpaperId =
  | "tuynuk"
  | "matritsa"
  | "aurora"
  | "yulduz"
  | "chog"
  | "nihol"
  | "orxideya"
  | "qum"
  | "ravoq"
  | "dengiz"
  | "yomgir"
  | "ipak"
  | "user-image"
  | "user-video"
  | "user-html";

export type SceneId = Exclude<WallpaperId, "tuynuk" | "user-image" | "user-video" | "user-html">;

export type FontId = "outfit" | "nunito" | "fraunces" | "cormorant" | "oswald" | "plex";

export type Layer = "back" | "front";

export const FONTS: { id: FontId; label: string; family: string }[] = [
  { id: "outfit", label: "Ince", family: "var(--font-outfit)" },
  { id: "nunito", label: "Yumaloq", family: "var(--font-nunito)" },
  { id: "fraunces", label: "Serif", family: "var(--font-fraunces)" },
  { id: "cormorant", label: "Klassik", family: "var(--font-cormorant)" },
  { id: "oswald", label: "Tor", family: "var(--font-oswald)" },
  { id: "plex", label: "Mono", family: "var(--font-plex)" },
];

export const WALLPAPERS: {
  id: Exclude<WallpaperId, "user-image" | "user-video" | "user-html">;
  name: string;
  group: "live" | "studio";
  depth: boolean;
}[] = [
  { id: "tuynuk", name: "Qora tuynuk", group: "live", depth: false },
  { id: "matritsa", name: "Matritsa", group: "live", depth: false },
  { id: "aurora", name: "Aurora", group: "live", depth: false },
  { id: "yulduz", name: "Yulduzlar", group: "live", depth: false },
  { id: "chog", name: "Cho‘g‘", group: "live", depth: false },
  { id: "nihol", name: "Nihol", group: "studio", depth: true },
  { id: "orxideya", name: "Orxideya", group: "studio", depth: true },
  { id: "qum", name: "Qumlar", group: "studio", depth: true },
  { id: "ravoq", name: "Ravoq", group: "studio", depth: true },
  { id: "dengiz", name: "Dengiz", group: "studio", depth: true },
  { id: "yomgir", name: "Yomg‘ir", group: "studio", depth: true },
  { id: "ipak", name: "Ipak", group: "studio", depth: true },
];

export function wallpaperMeta(id: WallpaperId) {
  return WALLPAPERS.find((item) => item.id === id);
}

export function isScene(id: WallpaperId): id is SceneId {
  return id !== "tuynuk" && id !== "user-image" && id !== "user-video" && id !== "user-html";
}

export function hasSceneFront(id: WallpaperId) {
  return wallpaperMeta(id)?.depth === true;
}

export function clockCssColor(color: string) {
  if (color === "ink") return "var(--color-ink)";
  if (color === "silver") return "var(--color-silver)";
  if (color === "amber") return "var(--color-amber)";
  return color;
}

export function colorToHex(color: string) {
  if (color === "silver") return "#d8d2c8";
  if (color === "amber") return "#e39a52";
  if (color.startsWith("#") && color.length >= 7) return color.slice(0, 7);
  return "#f4ece3";
}

export const DAYS = ["Yakshanba", "Dushanba", "Seshanba", "Chorshanba", "Payshanba", "Juma", "Shanba"];
export const MONTHS = [
  "yanvar",
  "fevral",
  "mart",
  "aprel",
  "may",
  "iyun",
  "iyul",
  "avgust",
  "sentabr",
  "oktabr",
  "noyabr",
  "dekabr",
];
