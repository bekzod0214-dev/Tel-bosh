import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { idbDel, idbSet, imageHasTransparency } from "@/lib/media-db";
import { type FontId, type WallpaperId, wallpaperMeta } from "@/lib/presets";
import sampleHtml from "@/wallpapers/qora-tuynuk.html?raw";

type Weight = 200 | 300 | 400 | 500 | 600;

type QatlamState = {
  wallpaper: WallpaperId;
  font: FontId;
  weight: Weight;
  scale: number;
  color: string;
  shadow: boolean;
  seconds: boolean;
  showDate: boolean;
  showClock: boolean;
  clockY: number;
  depth: boolean;
  maskX: number;
  maskY: number;
  maskW: number;
  maskH: number;
  feather: number;
  userImageHasAlpha: boolean;
  editing: boolean;
  imageUrl: string | null;
  videoUrl: string | null;
  html: string;
  mediaReady: boolean;
  notice: string | null;
  selectWallpaper: (id: WallpaperId) => void;
  setFont: (font: FontId) => void;
  setWeight: (weight: Weight) => void;
  setScale: (scale: number) => void;
  setColor: (color: string) => void;
  setShadow: (shadow: boolean) => void;
  setSeconds: (seconds: boolean) => void;
  setShowDate: (showDate: boolean) => void;
  setShowClock: (showClock: boolean) => void;
  setClockY: (clockY: number) => void;
  setDepth: (depth: boolean) => void;
  setMask: (patch: Partial<Pick<QatlamState, "maskX" | "maskY" | "maskW" | "maskH" | "feather">>) => void;
  setEditing: (editing: boolean) => void;
  clearNotice: () => void;
  useSampleHtml: () => Promise<void>;
  useImageFile: (file: File) => Promise<void>;
  useVideoFile: (file: File) => Promise<void>;
  useHtmlFile: (file: File) => Promise<void>;
  useHtmlText: (text: string) => Promise<void>;
  clearUserMedia: (kind: "image" | "video" | "html") => Promise<void>;
};

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function memoryStorage(): Pick<Storage, "getItem" | "setItem" | "removeItem"> {
  return {
    getItem: () => null,
    setItem: () => {},
    removeItem: () => {},
  };
}

export const useQatlam = create<QatlamState>()(
  persist(
    (set, get) => ({
      wallpaper: "qum",
      font: "outfit",
      weight: 200,
      scale: 1.08,
      color: "ink",
      shadow: true,
      seconds: false,
      showDate: true,
      showClock: true,
      clockY: 12,
      depth: true,
      maskX: 50,
      maskY: 62,
      maskW: 78,
      maskH: 52,
      feather: 16,
      userImageHasAlpha: false,
      editing: false,
      imageUrl: null,
      videoUrl: null,
      html: "",
      mediaReady: false,
      notice: null,
      selectWallpaper: (id) => {
        const meta = wallpaperMeta(id);
        set({
          wallpaper: id,
          depth: meta ? meta.depth : get().depth,
          showClock: true,
          notice: null,
        });
      },
      setFont: (font) => set({ font }),
      setWeight: (weight) => set({ weight }),
      setScale: (scale) => set({ scale: clamp(scale, 0.7, 1.5) }),
      setColor: (color) => set({ color }),
      setShadow: (shadow) => set({ shadow }),
      setSeconds: (seconds) => set({ seconds }),
      setShowDate: (showDate) => set({ showDate }),
      setShowClock: (showClock) => set({ showClock }),
      setClockY: (clockY) => set({ clockY: clamp(clockY, 6, 34) }),
      setDepth: (depth) => set({ depth }),
      setMask: (patch) => set(patch),
      setEditing: (editing) => set({ editing }),
      clearNotice: () => set({ notice: null }),
      useSampleHtml: async () => {
        await idbSet("html", sampleHtml);
        set({
          html: sampleHtml,
          wallpaper: "user-html",
          showClock: false,
          depth: false,
          notice: null,
        });
      },
      useImageFile: async (file) => {
        if (!file.type.startsWith("image/")) {
          set({ notice: "Rasm faylini tanlang." });
          return;
        }
        if (file.size > 12 * 1024 * 1024) {
          set({ notice: "Rasm 12 MB dan kichik bo‘lsin." });
          return;
        }
        let alpha = false;
        try {
          alpha = await imageHasTransparency(file);
        } catch {
          set({ notice: "Bu rasm ochilmadi. Boshqa formatni sinab ko‘ring." });
          return;
        }
        try {
          await idbSet("image", file);
        } catch {
          set({ notice: "Rasm sig‘madi. Kichikroq fayl tanlang." });
          return;
        }
        const prev = get().imageUrl;
        if (prev) URL.revokeObjectURL(prev);
        set({
          imageUrl: URL.createObjectURL(file),
          userImageHasAlpha: alpha,
          wallpaper: "user-image",
          depth: true,
          showClock: true,
          notice: alpha ? "Shaffof rasm aniqlandi — soat uning orqasida." : null,
        });
      },
      useVideoFile: async (file) => {
        if (!file.type.startsWith("video/")) {
          set({ notice: "Video faylini tanlang." });
          return;
        }
        if (file.size > 40 * 1024 * 1024) {
          set({ notice: "Video 40 MB dan kichik bo‘lsin." });
          return;
        }
        try {
          await idbSet("video", file);
        } catch {
          set({ notice: "Video sig‘madi. Kichikroq fayl tanlang." });
          return;
        }
        const prev = get().videoUrl;
        if (prev) URL.revokeObjectURL(prev);
        set({
          videoUrl: URL.createObjectURL(file),
          wallpaper: "user-video",
          depth: true,
          showClock: true,
          notice: null,
        });
      },
      useHtmlFile: async (file) => {
        if (file.size > 400_000) {
          set({ notice: "HTML 400 KB dan kichik bo‘lsin." });
          return;
        }
        const text = await file.text();
        await get().useHtmlText(text);
      },
      useHtmlText: async (text) => {
        const trimmed = text.trim();
        if (!trimmed) {
          set({ notice: "HTML kod bo‘sh." });
          return;
        }
        if (trimmed.length > 400_000) {
          set({ notice: "HTML 400 KB dan kichik bo‘lsin." });
          return;
        }
        try {
          await idbSet("html", trimmed);
        } catch {
          set({ notice: "HTML saqlanmadi." });
          return;
        }
        set({
          html: trimmed,
          wallpaper: "user-html",
          showClock: false,
          depth: false,
          notice: null,
        });
      },
      clearUserMedia: async (kind) => {
        const key = kind === "image" ? "image" : kind === "video" ? "video" : "html";
        await idbDel(key);
        if (kind === "image" && get().imageUrl) URL.revokeObjectURL(get().imageUrl!);
        if (kind === "video" && get().videoUrl) URL.revokeObjectURL(get().videoUrl!);
        const wallpaper = get().wallpaper;
        const drop =
          (kind === "image" && wallpaper === "user-image") ||
          (kind === "video" && wallpaper === "user-video") ||
          (kind === "html" && wallpaper === "user-html");
        set({
          imageUrl: kind === "image" ? null : get().imageUrl,
          videoUrl: kind === "video" ? null : get().videoUrl,
          html: kind === "html" ? "" : get().html,
          userImageHasAlpha: kind === "image" ? false : get().userImageHasAlpha,
          wallpaper: drop ? "qum" : wallpaper,
          depth: drop ? true : get().depth,
          showClock: true,
        });
      },
    }),
    {
      name: "qatlam-v1",
      skipHydration: true,
      storage: createJSONStorage(() => (typeof window === "undefined" ? memoryStorage() : localStorage)),
      partialize: (state) => ({
        wallpaper: state.wallpaper,
        font: state.font,
        weight: state.weight,
        scale: state.scale,
        color: state.color,
        shadow: state.shadow,
        seconds: state.seconds,
        showDate: state.showDate,
        showClock: state.showClock,
        clockY: state.clockY,
        depth: state.depth,
        maskX: state.maskX,
        maskY: state.maskY,
        maskW: state.maskW,
        maskH: state.maskH,
        feather: state.feather,
        userImageHasAlpha: state.userImageHasAlpha,
      }),
    },
  ),
);
